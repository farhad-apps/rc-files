<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Controllers\Admin;

class BaseController
{
    public $cont;
    public $templateName = "Admin/layouts/admin-layout.php";

    public $data = array(
        'pageTitle'         => '',
        'viewContent'       => '',
        'activeMenu'        => 'dashboard',
        'activeTheme'       => 'dark',
        'activeColor'       => 'preset-8',
        'activePage'        => 'dashboard',
        'appVersion'        => "2.0.3",
        'cacheDate'         => "",
        'showUpNotice'      => false,
        'siteTitle'         => "",
        'siteLogo'          => "",
        'licenseData'       => [],
    );

    function __construct($cont = null)
    {
        loadHelpers("admin");
        $this->cont = $cont;
        if (!empty($_COOKIE["panel-theme"])) {
            $this->data["activeTheme"] = $_COOKIE["panel-theme"];
        }
        if (!empty($_COOKIE["panel-color"])) {
            $this->data["activeColor"] = $_COOKIE["panel-color"];
        }

        $this->data["cacheDate"] = date("Y-m");

        $appVersion     = $this->data["appVersion"];

        $sModel         = new \App\Models\Settings();
        $settings       = $sModel->getSettings();
        $lastVersion    = getArrayValue($settings, "app_last_version");
        $siteTitle      = getArrayValue($settings, "site_title");
        $footerText     = getArrayValue($settings, "footer_text");


        $this->data["siteTitle"]    = $siteTitle ? $siteTitle : "Rocket SSH";
        $this->data["footerText"]   = $footerText;
        $this->data["siteLogo"]     = siteLogo();

        if (!empty($this->cont["licenseData"])) {
            $this->data["licenseData"]  = $this->cont["licenseData"];
        }

        if (version_compare($lastVersion, $appVersion, ">")) {
            $this->data["showUpNotice"] = true;
        }
    }


    public function __get($var)
    {
        return container()->{$var};
    }

    protected function initRoute($req, $res)
    {
        $this->request = $req;
        $this->response = $res;
    }

    public function setRequest($request)
    {
        $this->request = $request;
    }

    public function setResponse($response)
    {
        $this->response = $response;
    }

    public function render($data)
    {
        $prefixPageTitle    = $this->data["siteTitle"];
        $this->data         = array_merge($this->data, $data);
        $pageTitle          =  $this->data["pageTitle"] . " | " . $prefixPageTitle;
        $this->data["pageTitle"] = $pageTitle;


        if (!empty($this->cont["userInfo"])) {
            $userInfo = (array)$this->cont["userInfo"];
            $this->data["userInfo"]     = $userInfo;
            $this->data["userRole"]     = $userInfo["role"];
            $this->data["userCredit"]   = $userInfo["credit"];
        }
        if (!empty($this->cont["licenseData"])) {
            $this->data["licenseData"]  = $this->cont["licenseData"];
        }

        return $this->cont->view->render($this->response, $this->templateName, $this->data);
    }


    public function renderAjxView($data)
    {
        $html = $this->fetch($data);
        return $this->response->withStatus(200)->withJson(["html" => $html]);
    }

    public function fetch($data)
    {
        $this->templateName = 'Admin/layouts/ajax-layout.php';
        $this->data         = array_merge($this->data, $data);

        $userInfo = getSessionUser();
        if ($userInfo) {
            $this->data["userInfo"] = $userInfo;
            $this->data["userRole"] = $userInfo["role"];
        }
        if (!empty($this->cont["licenseData"])) {
            $this->data["licenseData"]  = $this->cont["licenseData"];
        }

        return $this->cont->view->fetch($this->templateName, $this->data);
    }
}
