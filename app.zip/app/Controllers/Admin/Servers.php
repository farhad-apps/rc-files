<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Controllers\Admin;

class Servers extends BaseController
{

    public function index($request, $response, $args)
    {
        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));
        enqueueScriptFooter(assets("vendor/datatable/datatables.js"));
        enqueueStyleHeader(assets("vendor/datatable/datatables.css"));

        $viewData   = [];
        $viewData["pageTitle"]      = "مدیریت سرور";
        $viewData["viewContent"]    = "servers/index.php";
        $viewData["activeMenu"]     = "servers";
        $viewData["activePage"]     = "servers";
        $viewData["activeTab"]      = "list";
        $this->render($viewData);
    }

    public function downloadOvpnConf($request, $response, $args)
    {
        $serverId       = $args['id'];
        $sModel         = new \App\Models\Servers();
        $serverInfo     = $sModel->getInfo($serverId);
        if ($serverInfo) {
            $ip         = $serverInfo->ip;
            $serverApi  =  new \App\Libraries\ServerApi($ip);
            try {
                $result = $serverApi->downloadOvpnUconfig();
                if (!empty($result["conf"])) {
                    $conf = $result["conf"];
                    $response = $response->withHeader('Content-Description', 'File Transfer')
                        ->withHeader('Content-Type', 'application/octet-stream')
                        ->withHeader('Content-Disposition', 'attachment;filename="file.ovpn"')
                        ->withHeader('Expires', '0')
                        ->withHeader('Cache-Control', 'must-revalidate')
                        ->withHeader('Pragma', 'public');

                    echo $conf;
                    return $response;
                } else {
                    throw new \Error("Invalid");
                }
            } catch (\Exception $err) {
                echo "Not Found";
            }
        }
    }

    public function resources($request, $response, $args)
    {
        enqueueScriptFooter(assets("vendor/circularProgressBar.min.js"));

        $viewData   = [];
        $viewData["pageTitle"]      = "منابع مصرفی سرورها";
        $viewData["viewContent"]    = "servers/index.php";
        $viewData["activeMenu"]     = "servers";
        $viewData["activePage"]     = "servers";
        $viewData["activeTab"]      = "resources";

        $this->render($viewData);
    }

    public function settings($request, $response, $args)
    {
        enqueueScriptFooter(assets("vendor/jquery-validate/jquery.validate.min.js"));

        $serverId       = $args['id'];
        $sModel         = new \App\Models\Servers();
        $serverInfo     = $sModel->getInfo($serverId);
        $licenseData    = $this->data["licenseData"];
        $viewData       = [];
        if ($serverInfo) {
            $subModel                   = new \App\Models\Subscribers();
            $activeUsers                = $subModel->getTotalActiveSubs();
            $protocols                  = $serverInfo->protocols;
            $activeProto                = $licenseData["active_protocols"];
            foreach ($protocols as  $k => $protocol) {
                if (!in_array($protocol, $activeProto)) {
                    unset($protocols[$k]);
                }
            }
            $serverInfo->protocols      = $protocols;
            $viewData["pageTitle"]      = "تنظیمات  سرور";
            $viewData["viewContent"]    = "servers/settings/index.php";
            $viewData["activeMenu"]     = "servers";
            $viewData["activePage"]     = "server-settings";
            $viewData["serverInfo"]     = $serverInfo;
            $viewData["activeUsers"]    = $activeUsers;
            $this->render($viewData);
        } else {
            return $response->withStatus(302)->withHeader("location", adminBaseUrl("servers"));
        }
    }

    public function ajaxViewAdd($request, $response, $args)
    {
        $cModel     = new \App\Models\Categories($this);
        $viewData   = [];

        $viewData['countries']      = getCountries();
        $viewData["categories"]     = $cModel->getAll();
        $viewData['viewContent']    = 'servers/form.php';

        return $this->renderAjxView($viewData);
    }

    public function ajaxViewEdit($request, $response, $args)
    {
        $editId         = $args["id"];
        $sModel         = new \App\Models\Servers();
        $serverInfo     = $sModel->getInfo($editId);

        $viewData       = [];
        if ($serverInfo) {
            $cModel     = new \App\Models\Categories($this);

            $viewData['countries']     = getCountries();
            $viewData['formValues']    = $serverInfo;
            $viewData["categories"]    = $cModel->getAll();
            $viewData['viewContent']   = 'servers/form.php';
            return $this->renderAjxView($viewData);
        } else {
            $viewData['viewContent']   = 'notfound-modal.php';
        }

        return $this->renderAjxView($viewData);
    }

    public function ajaxViewFiltering($request, $response, $args)
    {
        $editId         = $args["id"];
        $sModel         = new \App\Models\Servers();
        $serverInfo     = $sModel->getInfo($editId);

        $viewData       = [];
        if ($serverInfo) {
            $sModel         = new \App\Models\Settings();
            $serversSSH     = $sModel->getSetting("servers_ssh");
            $sshPort        = getArrayValue($serversSSH, "port", "");

            $viewData['sshPort']        = $sshPort;
            $viewData['formValues']     = $serverInfo;
            $viewData['viewContent']    = 'servers/filtering.php';
            return $this->renderAjxView($viewData);
        } else {
            $viewData['viewContent']   = 'notfound-modal.php';
        }

        return $this->renderAjxView($viewData);
    }

    public function ajaxAddServer($request, $response, $args)
    {
        $uid       = $request->getAttribute('uid');
        $pdata     = $request->getParsedBody();
        $result    = \App\Validations\Servers::save($pdata);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $sModel = new \App\Models\Servers();
        try {
            $result = $sModel->saveServer($pdata, $uid);

            return $response->withStatus(200)->withJson([
                "is_configured"     => 0,
                "server_id"         => $result
            ]);
        } catch (\Exception $err) {

            $result["status"] = "error";
            $result["messages"] = "در افزودن سرور خطایی رخ داد. لطفا دوباره امتحان کنید";
            return $response->withStatus(400)->withJson($result);
        }
    }

    public function ajaxServersList($request, $response, $args)
    {
        $pdata          = $request->getParsedBody();
        $sModel         = new \App\Models\Servers($this);
        $uid            = $request->getAttribute('uid');
        $licenseData    = $request->getAttribute('licenseData');

        $result         = $sModel->dataTableList($pdata, $licenseData["plan_name"], $uid);
        return $response->withStatus(200)->withJson($result);
    }


    public function ajaxEditServer($request, $response, $args)
    {
        $editId    = $args["id"];
        $uid       = $request->getAttribute('uid');
        $pdata     = $request->getParsedBody();
        $result    = \App\Validations\Servers::save($pdata, $editId);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $sModel     = new \App\Models\Servers();
        $setModel   = new \App\Models\Settings();
        try {
            $sModel->saveServer($pdata, $uid, $editId);
            $serverInfo = $sModel->getInfo($editId);

            $ip                 = $serverInfo->ip;
            $sshUser            = $serverInfo->ssh_user;
            $sshPass            = $serverInfo->ssh_pass;
            $sshPort            = $serverInfo->ssh_port;
            $protocols          = $serverInfo->protocols;

            $enableSsh          = in_array("ssh", $protocols);
            $enabledOvpn        = in_array("openvpn", $protocols);
            $enabledV2ray       = in_array("v2ray", $protocols);

            $settings           = $setModel->getSettings();
            $serversToken       = getArrayValue($settings, "servers_token", "");
            $serversSSH         = getArrayValue($settings, "servers_ssh", []);
            $serversV2ray       = getArrayValue($settings, "servers_v2ray", []);
            $serversOpenvpn     = getArrayValue($settings, "servers_openvpn", []);

            $v2rayDomain        = $serverInfo->v2ray_domain;
            $openvpnDomain      = $serverInfo->openvpn_domain;
            $sshDomain          = $serverInfo->ssh_domain;

            $configsArr  = [
                "api_token"     => $serversToken,
                "api_url"       => baseUrl("sapi"),
            ];

            if ($enableSsh) {
                $serversSSH["domain"] = $sshDomain;
                $configsArr["servers_ssh"] = $serversSSH;
            }

            if ($enabledOvpn) {
                $serversOpenvpn["domain"]       = $openvpnDomain;
                $configsArr["servers_openvpn"]  = $serversOpenvpn;
            }

            if ($enabledV2ray) {
                $serversV2ray["domain"]         = $v2rayDomain;
                $configsArr["servers_v2ray"]    = $serversV2ray;
            }

            $serverNet = new  \App\Libraries\ServerNet();

            $serverNet->setConfig($ip, $sshUser, $sshPass, $sshPort);
            $serverNet->login();
            $serverNet->setupConfigFile($configsArr);


            return $response->withStatus(200)->withJson([
                "is_configured"     => $serverInfo->is_configured,
                "server_id"         => $editId
            ]);
        } catch (\Exception $err) {

            $result["status"] = "error";
            $result["messages"] = "در ویرایش سرور خطایی رخ داد. لطفا دوباره امتحان کنید";
            return $response->withStatus(400)->withJson($result);
        }
    }

    public function ajaxDeleteServer($request, $response, $args)
    {
        $id        = $args["id"];
        $uid       = $request->getAttribute('uid');

        $result    = \App\Validations\Servers::hasExist($id);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $sModel = new \App\Models\Servers();
        $sModel->deleteServer($id, $uid);

        return $response->withStatus(200);
    }


    public function ajaxSyncUsers($request, $response, $args)
    {
        $id        = $args["id"];
        $result    = \App\Validations\Servers::hasExist($id);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $lastUid    = $request->getQueryParam('last_id');
        $sModel     = new \App\Models\Servers();
        try {
            $lastUid    = $lastUid ? $lastUid : 0;
            $lastUserId = $sModel->syncUsers($id, $lastUid);
            $result["last_id"] = $lastUserId;

            return $response->withStatus(200)->withJson($result);
        } catch (\Exception $err) {
            $result["status"] = "error";
            $result["message"] = "خطایی رخ داد دوباره امتحان کنید";
            return $response->withStatus(400)->withJson($result);
        }
    }

    public function ajaxToggleServerActive($request, $response, $args)
    {
        $editId    = $args["id"];
        $uid       = $request->getAttribute('uid');
        $result    = \App\Validations\Servers::hasExist($editId);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        $sModel = new \App\Models\Servers();
        $sModel->toggleActive($editId, $uid);
        $serverInfo =  $sModel->getInfo($editId);
        $categories = [];

        if (!empty($serverInfo->ssh_category)) {
            $categories[] = $serverInfo->ssh_category;
        }
        if (!empty($serverInfo->v2ray_category)) {
            $categories[] = $serverInfo->v2ray_category;
        }
        if (!empty($serverInfo->openvpn_category)) {
            $categories[] = $serverInfo->openvpn_category;
        }
        return $response->withStatus(200)->withJson(["categories" => $categories]);
    }

    public function ajaxGetCategories($request, $response, $args)
    {
        $serverId   = $args["id"];
        $sModel     = new \App\Models\Servers();
        $serverInfo =  $sModel->getInfo($serverId);
        $categories = [];

        if (!empty($serverInfo->ssh_category)) {
            $categories[] = $serverInfo->ssh_category;
        }
        if (!empty($serverInfo->v2ray_category)) {
            $categories[] = $serverInfo->v2ray_category;
        }
        if (!empty($serverInfo->openvpn_category)) {
            $categories[] = $serverInfo->openvpn_category;
        }
        return $response->withStatus(200)->withJson(["categories" => $categories]);
    }

    public function ajaxSysData($request, $response, $args)
    {
        $serverId   = $args["id"];
        $sModel     = new \App\Models\Servers();
        try {
            $result = $sModel->getResources($serverId);
            return $response->withStatus(200)->withJson($result);
        } catch (\Exception $err) {
            return $response->withStatus(400)->withJson([
                "messages" => "ارتباط با سرور برقرار نشد"
            ]);
        }
    }

    public function ajaxInstallProtocols($request, $response, $args)
    {
        $serverId   = $args["id"];
        $sModel     = new \App\Models\Servers();
        $serverInfo =  $sModel->getInfo($serverId);
        $pdata      = $request->getParsedBody();
        if ($serverInfo) {
            $ip         = $serverInfo->ip;
            $sApi       = new  \App\Libraries\ServerApi($ip);
            if (empty($pdata["protocol"])) {
                $command    = "/var/rocket-ssh/installer setup-all > /var/rocket-ssh/setup-all.log 2>&1 &";
                $sApi->execCommand($command);
            } else {
                $protocol   = $pdata["protocol"];
                $command    = "/var/rocket-ssh/installer setup-$protocol > /var/rocket-ssh/setup-$protocol.log 2>&1 &";
                $sApi->execCommand($command);
            }
        }
    }

    public function ajaxInstallLogProtocols($request, $response, $args)
    {
        $serverId   = $args["id"];
        $sModel     = new \App\Models\Servers();
        $serverInfo =  $sModel->getInfo($serverId);
        $pdata      = $request->getParsedBody();
        if ($serverInfo) {
            $ip         = $serverInfo->ip;
            $sApi       = new  \App\Libraries\ServerApi($ip);
            if (empty($pdata["protocol"])) {
                $command    = "cat /var/rocket-ssh/setup-all.log";
            } else {
                $protocol = $pdata["protocol"];
                $command    = "cat /var/rocket-ssh/setup-$protocol.log";
            }
            $return = [
                "logs" => "",
            ];
            try {
                $_response  = $sApi->execCommand($command);
                if (!empty($_response["result"])) {
                    $result             = $_response["result"];
                    $return["logs"]     = $result;
                    $instllProtocols    = getInstalledProtocolsLogs($result);
                    $return = array_merge($return, $instllProtocols);
                }
            } catch (\Exception $err) {
            }

            return $response->withStatus(200)->withJson($return);
        }
    }

    public function ajaxResetServices($request, $response, $args)
    {
        $serverId   = $args["id"];
        $sModel     = new \App\Models\Servers();
        $serverInfo =  $sModel->getInfo($serverId);
        $pdata      = $request->getParsedBody();
        if ($serverInfo) {
            $ip         = $serverInfo->ip;
            $sApi       = new  \App\Libraries\ServerApi($ip);
            $service    = $pdata["service"];
            if ($service == "ssh") {
            }
            if ($service == "ssh") {
                $command    = "systemctl restart ssh";
                $sApi->execCommand($command);
                $command    = "systemctl restart sshd";
                $sApi->execCommand($command);
            } else if ($service == "v2ray") {
                $command    = "systemctl restart rsxray";
                $sApi->execCommand($command);
            } else if ($service == "openvpn") {
                $command    = "systemctl restart openvpn";
                $sApi->execCommand($command);
            } else if ($service == "rocketApp") {
                $command    = "supervisorctl restart rocketApp";
                $sApi->execCommand($command);
            }
        }
    }

    public function ajaxResourcesHtml($request, $response, $args)
    {
        $serverId   = $args["id"];
        $sModel     = new \App\Models\Servers();
        try {
            $result = $sModel->getResources($serverId);
            $data = [
                "viewContent"   => "servers/single-resource.php",
                "resources"     => $result,
                "serverId"      => $serverId
            ];

            $html = $this->fetch($data);
            return $response->withStatus(200)->withJson(["html" => $html]);
        } catch (\Exception $err) {
            return $response->withStatus(400)->withJson([
                "messages" => "ارتباط با سرور برقرار نشد"
            ]);
        }
    }

    public function ajaxGetAllActive($request, $response, $args)
    {
        $sModel     = new \App\Models\Servers();
        $result     = $sModel->getAllActive();
        if ($result) {
            return $response->withStatus(200)->withJson($result);
        }
        return $response->withStatus(404);
    }

    public function ajaxConfigure($request, $response, $args)
    {
        $editId     = $args["id"];
        $sModel     = new \App\Models\Servers();
        $result     = $sModel->setupServer($editId);
        if ($result["status"] == "error") {
            return $response->withStatus(400)->withJson($result);
        }

        return $response->withStatus(200)->withJson($result);
    }

    public function ajaxActionUsers($request, $response, $args)
    {
        $editId     = $args["id"];
        $sModel     = new \App\Models\Servers();

        $serverInfo = $sModel->getInfo($editId);

        $result = ["status" => "success"];
        if ($serverInfo) {
            $subsModel  = new \App\Models\Subscribers();
            $pdata      = $request->getParsedBody();
            $action     = $pdata["action"];
            $users      = [];
            if (!empty($pdata["ids"])) {
                $userIds    = $pdata["ids"];
                $users      = $subsModel->getUserPassByIds($userIds);
            } else {
                if ($action == "sync-all") {
                    $users   = $subsModel->getSyncUsers();
                    $action  = "create";
                }
            }

            if (!empty($users)) {
                $ip         = $serverInfo->ip;
                $serverApi  =  new \App\Libraries\ServerApi($ip);
                $serverName = $serverInfo->name;

                try {
                    $susers = [];
                    foreach ($users  as $user) {
                        $username   = $user->username;
                        $password   = $user->password;
                        $uuid       = $user->uuid;
                        $susers[]   = [
                            "username"  => $username,
                            "password"  => $password,
                            "uuid"      => $uuid
                        ];
                    }

                    if ($action == "create") {
                        $serverApi->createUsers($susers);
                    } else if ($action == "update") {
                        $serverApi->updateUsers($susers);
                    } else if ($action == "delete") {
                        $serverApi->removeUsers($susers);
                    } else if ($action == "activate") {
                        $serverApi->createUsers($susers);
                    } else if ($action == "deactivate") {
                        $serverApi->removeUsers($susers);
                    }
                } catch (\Exception $err) {
                    $result = ["status" => "error", "messages" => ["عملیات در سرور $serverName با خطا مواجه شد"]];
                }
            } else {
                $result["status"] = "error";
                $result["msg"] = "هیچ مشترکی یافت نشد";
            }
        }

        if ($result["status"] == "success") {
            return $response->withStatus(200)->withJson($result);
        }

        return $response->withStatus(400)->withJson($result);
    }

    public function ajaxRunCommand($request, $response, $args)
    {
        $serverId   = $args["id"];
        $pdata      = $request->getParsedBody();
        $sModel     = new \App\Models\Servers();
        $serverInfo = $sModel->getInfo($serverId);

        $result     = ["status" => "success"];

        if ($serverInfo) {
            $ip        = $serverInfo->ip;
            $sshUser   = $serverInfo->ssh_user;
            $sshPass   = $serverInfo->ssh_pass;
            $sshPort   = $serverInfo->ssh_port;

            $serverNet = new  \App\Libraries\ServerNet();

            $command   = !empty($pdata["cmd"]) ? $pdata["cmd"] : "";
            try {
                $serverNet->setConfig($ip, $sshUser, $sshPass, $sshPort);
                $serverNet->login();

                if ($command == "reset-rocketApp") {
                    $serverNet->resetRocketApp();
                } else if ($command == "update-rocketApp") {
                    $serverNet->updateRocketApp();
                } else if ($command == "reboot-server") {
                    $serverNet->rebootServer();
                }

                $serverNet->disconnect();
            } catch (\Exception $err) {
                $result = ["status" => "error", "messages" => $err->getMessage()];
            }
        } else {
            $result = ["status" => "error", "messages" => "اطلاعات سرور یافت نشد"];
        }

        if ($result["status"] == "success") {
            return $response->withStatus(200)->withJson($result);
        }

        return $response->withStatus(400)->withJson($result);
    }

    public function ajaxDlOvpnCerts($request, $response, $args)
    {
        $serverId   = $args["id"];
        $sModel     = new \App\Models\Servers();

        $serverInfo = $sModel->getInfo($serverId);
        if ($serverInfo) {
            $ip         = $serverInfo->ip;
            $serverApi  = new \App\Libraries\ServerApi($ip);

            $filesPath  = "/etc/openvpn";
            $files      = ["tc.key", "server.crt", "server.key", "dh.pem", "client.key", "client.crt", "ca.crt"];

            $command    = "cd $filesPath &&  zip -r certs.zip " . implode(" ", $files);
            $serverApi->execCommand($command);

            $filesPath  = "/etc/openvpn/certs.zip";
            $_response  = $serverApi->downloadFile($filesPath);
            if (!empty($_response)) {
                $filename = "ovpn-$ip-certs.zip";
                $response = $response->withHeader('Content-Type', 'application/zip')
                    ->withHeader('Content-Disposition', 'attachment; filename="' . $filename . '"');
                $response->getBody()->write($_response);

                return $response;
            }
        }
    }

    public function ajaxUpOvpnCerts($request, $response, $args)
    {
        $serverId   = $args["id"];
        $sModel     = new \App\Models\Servers();

        $serverInfo = $sModel->getInfo($serverId);
        $pass       = true;
        $messages   = [];
        if ($serverInfo) {
            $uploadedFiles = $request->getUploadedFiles();
            if (!empty($uploadedFiles["zipfile"])) {
                $upZipfile  = $uploadedFiles["zipfile"];
                $directory  = PATH_STORAGE;
                $filename   = moveUploadedFile($directory, $upZipfile);

                $filePath   = $directory . DS . $filename;
                $filesList  = getZipFiles($filePath);
                if (!empty($filesList) && count($filesList) == 7) {
                    $serverNet = new  \App\Libraries\ServerNet();

                    $ip        = $serverInfo->ip;
                    $sshUser   = $serverInfo->ssh_user;
                    $sshPass   = $serverInfo->ssh_pass;
                    $sshPort   = $serverInfo->ssh_port;

                    try {
                        $serverNet->setConfig($ip, $sshUser, $sshPass, $sshPort);
                        $serverNet->login();
                        $serverNet->uploadOvpnCerts($filePath);
                        $serverNet->disconnect();
                    } catch (\Exception $err) {
                        $pass       = false;
                        $messages[] = "در آپلود فایل خطایی رخ داد. دوباره آپلود کنید";
                    }
                } else {
                    $pass       = false;
                    $messages[] = "اطلاعات فایل ارسالی صحیح نیست";
                }
                @unlink($filePath);
            } else {
                $pass       = false;
                $messages[] = "اطلاعات فایل ارسالی صحیح نیست";
            }
        } else {
            $pass       = false;
            $messages[] = "در آپلود فایل خطایی رخ داد. دوباره آپلود کنید";
        }

        if (!$pass) {
            return $response->withStatus(400)->withJson($messages);
        }
        return $response->withStatus(200);
    }


    public function ajxKillOnlienUsers($request, $response, $args)
    {
        $serverId   = $args["id"];
        $sModel     = new \App\Models\Servers();

        $serverInfo = $sModel->getInfo($serverId);
        if ($serverInfo) {

            $uoModel        = new \App\Models\UsersOnline();
            $onlienUsers    = $uoModel->getServerUsers($serverId);
            if ($onlienUsers) {
                $actionUsers = [];

                foreach ($onlienUsers  as $user) {
                    $actionUsers[]  = ["username" => $user->username];
                }
                $ip         = $serverInfo->ip;
                $serverApi  = new \App\Libraries\ServerApi($ip);
                try {
                    $serverApi->killUsers($actionUsers);
                } catch (\Exception $err) {
                }

                $uoModel->deleteServerUsers($serverId);
            }
        }
    }
}
