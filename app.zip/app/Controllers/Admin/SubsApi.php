<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Controllers\Admin;


class SubsApi
{

    public function userInfoByToken($request, $response, $args)
    {
        $token  = $args["token"];

        $uModel = new \App\Models\Subscribers();
        $result = $uModel->getDetailsByToken($token);

        if (!empty($result)) {
            return $response->withStatus(200)->withJson($result);
        }

        return $response->withStatus(404);
    }

    public function settings($request, $response, $args)
    {

        $sModel     = new \App\Models\Settings();
        $settings   = $sModel->getSetting("users_panel");
        if (empty($settings)) {
            $settings = [];
        }
        return $response->withStatus(200)->withJson($settings);
    }

    public function Login($request, $response, $args)
    {

        $pdata      = $request->getParsedBody();
        if (!empty($pdata["username"]) && !empty($pdata["password"])) {
            $password   = $pdata["password"];
            $usename    = $pdata["username"];

            $uModel = new \App\Models\Subscribers();
            $token = $uModel->getLoginToken($usename, $password);
            if ($token) {
                return $response->withStatus(200)->withJson(["token" => $token]);
            }
        }
        return $response->withStatus(404);
    }
}
