<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Controllers\Admin;


class Pages extends BaseController
{

    public function notFoundPage($request, $response)
    {
        enqueueStyleHeader(assets("css/404.css"));

        $response = new \Slim\Http\Response(404);
        $this->setResponse($response);
        $this->templateName = "404-layout.php";
        $viewData = array();
        $viewData["pageTitle"] = "404";
        return $this->render($viewData);
    }

    public function ajaxCheckHost($request, $response, $args)
    {
        $pdata     = $request->getParsedBody();
        if (!empty($pdata["host"])) {
            $host       = $pdata["host"];

            $chkHost    = new \App\Libraries\CheckHostApi($host);
            $reqId      = $chkHost->getRequestId();
            if (!empty($reqId)) {
                sleep(10);
                $respons = $chkHost->checkResult();
                if (!empty($respons)) {
                    $result = $chkHost->parseResponse($respons);
                    return $response->withStatus(200)->withJson($result);
                }
            }
        }
        return $response->withStatus(400);
    }
}
