<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Controllers\Admin;

class Reports extends BaseController
{

    public function index($request, $response, $args)
    {

        $userInfo   = $request->getAttribute('userInfo');
        $uid        = $request->getAttribute('uid');
        $userRole   = $userInfo->role;

        enqueueScriptFooter(assets("vendor/chartjs/chartjs.min.js"));

        $viewData   = [];
        $viewData["pageTitle"]      = "گزارش گیری";
        $viewData["viewContent"]    = "reports/index.php";
        $viewData["activeMenu"]     = "reports";
        $viewData["activePage"]     = "reports";
        $viewData["activeTab"]      = "all";

        $rModel         = new \App\Models\Reports();

        $viewData["subsMonth"] = $rModel->subscribers(30, $userRole, $uid);

        if ($userRole == "admin") {
            $viewData["resellersSubs"]  = $rModel->resellersSubs();
        }

        $this->render($viewData);
    }

    public function credits($request, $response, $args)
    {
        enqueueScriptFooter(assets("vendor/datatable/datatables.js"));
        enqueueStyleHeader(assets("vendor/datatable/datatables.css"));

        $userInfo   = $request->getAttribute('userInfo');


        $viewData   = [];
        $viewData["pageTitle"]      = "گزارشات مالی";
        $viewData["viewContent"]    = "reports/index.php";
        $viewData["activeMenu"]     = "reports";
        $viewData["activePage"]     = "report-credits";
        $viewData["activeTab"]      = "credits";

        $this->render($viewData);
    }

    public function logs($request, $response, $args)
    {
        enqueueScriptFooter(assets("vendor/datatable/datatables.js"));
        enqueueStyleHeader(assets("vendor/datatable/datatables.css"));


        $viewData   = [];
        $viewData["pageTitle"]      = "لاگ ها";
        $viewData["viewContent"]    = "reports/index.php";
        $viewData["activeMenu"]     = "reports";
        $viewData["activePage"]     = "logs";
        $viewData["activeTab"]      = "logs";

        $this->render($viewData);
    }


    public function ajaxCreditsList($request, $response, $args)
    {
        $uid        = $request->getAttribute('uid');
        $userInfo   = $request->getAttribute('userInfo');

        $pdata      = $request->getQueryParams();
        $cModel     = new \App\Models\Credits();

        $userRole   = $userInfo->role;
        $result     = $cModel->dataTableList($pdata, $userRole, $uid);
        return $response->withStatus(200)->withJson($result);
    }


    public function ajaxLogsList($request, $response, $args)
    {
        $uid        = $request->getAttribute('uid');
        $userInfo   = $request->getAttribute('userInfo');

        $pdata      = $request->getQueryParams();
        $sModel     = new \App\Models\SysLogs();

        $userRole   = $userInfo->role;
        $result     = $sModel->dataTableList($pdata, $userRole, $uid);
        return $response->withStatus(200)->withJson($result);
    }
}
