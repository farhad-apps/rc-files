<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Controllers;


class ServerApi
{

    public function sshUlogin($request, $response, $args)
    {
        $serverIp   = !empty($_SERVER["REMOTE_ADDR"]) ? $_SERVER["REMOTE_ADDR"] : "";
        $username   = $request->getQueryParam('username');
        $userIp     = $request->getQueryParam('user_ip');
        $sessionKey = $request->getQueryParam('session_key');
        $pid        = $request->getQueryParam('pid');


        if (!empty($username) && !empty($userIp) && !empty($sessionKey)) {

            $sModel         = new \App\Models\Servers();
            $usModel        = new \App\Models\Subscribers();
            $clModel        = new \App\Models\ConnLogs();

            $userInfo       = $usModel->getUserServerLogin($username);
            $serverInfo     = $sModel->getServerByIp($serverIp);

            if ($userInfo && $serverInfo) {
                $passConn       = true;
                $validityDays   = $userInfo->validity_days;
                $userId         = $userInfo->user_id;
                $endDate        = $userInfo->end_time;
                $limitUsers     = $userInfo->limit_users;
                $totalOnline    = $userInfo->total_online;
                $serverId       = $serverInfo->id;

                // for first login
                if (!$userInfo->start_time) {
                    $usuModel   = new \App\Models\UsersSubs();
                    $startDate  = date("Y/m/d H:i:s");
                    $endDate    = date('Y/m/d H:i:s', strtotime($startDate . " + $validityDays days"));

                    $usuModel->setEndTime($userId, $startDate, $endDate);
                }

                if ($limitUsers > $totalOnline) {
                    $uoModel = new \App\Models\UsersOnline();
                    //add online
                    $uoModel->addOnlineUser($userId, $serverId, $userIp, $sessionKey, $pid);
                    $clModel->addLoginTime($userId, $serverId, $pid);
                } else {
                    $passConn = false;
                }

                if ($passConn) {
                    return $response->withStatus(200);
                }
            }
        }

        return $response->withStatus(401);
    }

    public function sshUlogout($request, $response, $args)
    {
        $serverIp   = !empty($_SERVER["REMOTE_ADDR"]) ? $_SERVER["REMOTE_ADDR"] : "";
        $username   = $request->getQueryParam('username');
        $userIp     = $request->getQueryParam('user_ip');
        $sessionKey = $request->getQueryParam('session_key');
        $pid        = $request->getQueryParam('pid');

        if (!empty($username) && !empty($userIp) && !empty($sessionKey) && $pid) {

            $suModel    = new \App\Models\Subscribers();
            $sModel     = new \App\Models\Servers();
            $clModel    = new \App\Models\ConnLogs();

            $userInfo   = $suModel->getByUsername($username);
            $serverInfo = $sModel->getServerByIp($serverIp);

            if ($userInfo && $serverInfo) {
                $userId     = $userInfo->user_id;
                $serverId   = $serverInfo->id;

                $uoModel    = new \App\Models\UsersOnline();
                $uoModel->removeOnlineUser($userId, $serverId, $sessionKey);

                $clModel->addLogoutTime($userId, $serverId, $pid);
            }
        }
    }

    public function sshUserActivities($request, $response, $args)
    {
        $pdata      = $request->getParsedBody();
        $serverIp   = !empty($_SERVER["REMOTE_ADDR"]) ? $_SERVER["REMOTE_ADDR"] : "";
        if (!empty($pdata["pid_list"])) {
            $sModel     = new \App\Models\Servers();
            $serverInfo = $sModel->getServerByIp($serverIp);
            if ($serverInfo) {
                $list       = $pdata["pid_list"];
                $list       = base64_decode($list);
                $listArr    = preg_split("/\r\n|\n|\r/", $list);

                if (!empty($listArr)) {
                    \App\Models\UsersOnline::whereIn("pid", $listArr)
                        ->where("server_id", $serverInfo->id)
                        ->update(["last_activity" => time()]);
                }
            }
        }
    }

    public function sshUserBanner($request, $response, $args)
    {
        $html = "";
        $username   = $request->getQueryParam('username');
        if (!empty($username)) {
            $suModel        = new \App\Models\Subscribers();
            $userInfo       = $suModel->getByUsername($username);

            if ($userInfo) {
                $bannerPath = PATH_APP . DS . "Views" . DS . "user-banner.php";
                $vars   = ["userInfo" => $userInfo];
                $html   = includeWithVariables($bannerPath, $vars, false);
            }
        }
        echo $html;
        die();
    }

    public function sshTraffics($request, $response, $args)
    {
        $pdata     = $request->getParsedBody();


        if (!empty($pdata["data"])) {
            $data       = $pdata["data"];

            $tcontent   = base64_decode($data);
            $trafficlog = preg_split("/\r\n|\n|\r/", $tcontent);
            $trafficlog = array_filter($trafficlog);
            $lastdata   = end($trafficlog);
            $jsonData   = json_decode($lastdata, true);

            $uModel     = new \App\Models\Users();
            $sModel     = new \App\Models\Subscribers();
            $utModel    = new \App\Models\UsersTraffics();
            $seModel    = new \App\Models\Settings();

            $allUsers   = $sModel->getAllUsernames();

            $allUsers   = $allUsers ? $allUsers : [];

            if (is_array($jsonData)) {

                $userTraffics   = [];
                foreach ($jsonData as $value) {
                    $TX         = round($value["TX"], 0);
                    $RX         = round($value["RX"], 0);
                    $username   = preg_replace("/\\s+/", "", $value["name"]);
                    $username   = str_replace("sshd:", "", $username);
                    if (in_array($username, $allUsers)) {
                        if (isset($userTraffics[$username])) {
                            $userTraffics[$username]["TX"] + $TX;
                            $userTraffics[$username]["RX"] + $RX;
                        } else {
                            $userTraffics[$username] = ["RX" => $RX, "TX" => $TX, "Total" => $RX + $TX];
                        }
                    }
                }

                //ssh traffic coefficient
                $sshSettings  = $seModel->getSetting("servers_ssh");
                $tcoefficient = getArrayValue($sshSettings, "traffic_coefficient", "");
                $tcoefficient = $tcoefficient ? $tcoefficient : 12;

                foreach ($userTraffics as $username => $data) {
                    $userId      = $uModel->getIdByUsername($username);
                    if ($userId) {
                        $traffic = $utModel->getUserTraffic($userId);

                        $rx     = round($data["RX"]);
                        $rx     = $rx / 10;
                        $rx     = round(($rx / $tcoefficient) * 100);

                        $tx     = round($data["TX"]);
                        $tx     = $tx / 10;
                        $tx     = round(($tx / $tcoefficient) * 100);
                        $total = $rx + $tx;

                        $trafficColumn = [
                            "upload"    => $tx,
                            "download"  => $rx,
                            "total"     => $total,
                            "user_id"   => $userId,
                        ];
                        if ($traffic) {
                            $trafficColumn["upload"]    += $traffic->upload;
                            $trafficColumn["download"]  += $traffic->download;
                            $trafficColumn["total"]     += $traffic->total;
                            $trafficColumn["utime"]     = time();
                        } else {
                            $trafficColumn["ctime"]     = time();
                            $trafficColumn["utime"]     = 0;
                        }

                        \App\Models\UsersTraffics::updateOrCreate(["id" =>  $traffic->id], $trafficColumn);
                    }
                }
            }
        }
    }

    public function getSettings($request, $response, $args)
    {
        $servModel      = new \App\Models\Servers();
        $serverIp       = !empty($_SERVER["REMOTE_ADDR"]) ? $_SERVER["REMOTE_ADDR"] : "";
        $sModel         = new \App\Models\Settings();
        $calcTraffic    = $sModel->getSetting("servers_calc_traffic");
        $serverInfo     = $servModel->getServerByIp($serverIp);

        $result         = [
            "enabled_ssh"       => 0,
            "enabled_openvpn"   => 0,
            "enabled_v2ray"     => 0,
            "calc_traffic"      => 1,
        ];

        if ($calcTraffic !== false) {
            $result["calc_traffic"] = intval($calcTraffic);
        }

        if ($serverInfo) {
            $protocols      = $serverInfo->protocols;

            $enableSsh      = in_array("ssh", $protocols);
            $enabledOvpn    = in_array("openvpn", $protocols);
            $enabledV2ray   = in_array("v2ray", $protocols);

            $result["enabled_ssh"]      = $enableSsh ? 1 : 0;
            $result["enabled_openvpn"]  = $enabledOvpn ? 1 : 0;
            $result["enabled_v2ray"]    = $enabledV2ray ? 1 : 0;
        }

        return $response->withStatus(200)->withJson($result);
    }


    /** OVPN User Actions */

    public function ovpnULogin($request, $response, $args)
    {
        $pdata  = $request->getParsedBody();
        if (!empty($pdata["data"])) {
            $data       = base64_decode($pdata["data"]);

            $data       = json_decode($data, true);
            $usModel    = new \App\Models\Subscribers();

            $username   = $data["username"];
            $userInfo   = $usModel->getUserServerLogin($username);
            if ($userInfo) {
                $limitUsers     = $userInfo->limit_users;
                $totalOnline    = $userInfo->total_online;
                if ($limitUsers > $totalOnline) {
                    return $response->withStatus(200);
                }
            }
        }

        return $response->withStatus(401);
    }

    public function ovpnUConnect($request, $response, $args)
    {
        $pdata  = $request->getParsedBody();
        if (!empty($pdata["data"])) {
            $data       = base64_decode($pdata["data"]);
            $data       = json_decode($data, true);

            $username   = $data["username"];
            $userIp     = $data["user_ip"];
            $serverIp   = $data["server_ip"];
            $pid        = $data["pid"];

            $sModel     = new \App\Models\Servers();
            $usModel    = new \App\Models\Subscribers();
            $clModel    = new \App\Models\ConnLogs();

            $userInfo   = $usModel->getUserServerLogin($username);
            $serverInfo = $sModel->getServerByIp($serverIp);

            if ($userInfo && $serverInfo) {
                $validityDays   = $userInfo->validity_days;
                $userId         = $userInfo->user_id;
                $endDate        = $userInfo->end_time;
                $serverId       = $serverInfo->id;

                // for first login
                if (!$userInfo->start_time) {
                    $usuModel   = new \App\Models\UsersSubs();
                    $startDate  = date("Y/m/d H:i:s");
                    $endDate    = date('Y/m/d H:i:s', strtotime($startDate . " + $validityDays days"));
                    $usuModel->setEndTime($userId, $startDate, $endDate);
                }

                $uoModel = new \App\Models\UsersOnline();
                //add online
                $uoModel->addOnlineUser($userId, $serverId, $userIp, $pid, $pid, "openvpn");
                $clModel->addLoginTime($userId, $serverId, $pid, "openvpn");

                return $response->withStatus(200);
            }
        }
        return $response->withStatus(401);
    }

    public function ovpnUDisconnect($request, $response, $args)
    {
        $pdata  = $request->getParsedBody();
        if (!empty($pdata["data"])) {
            $data       = base64_decode($pdata["data"]);
            $data       = json_decode($data, true);

            $username   = $data["username"];
            $serverIp   = $data["server_ip"];
            $pid        = $data["pid"];

            $suModel    = new \App\Models\Subscribers();
            $sModel     = new \App\Models\Servers();
            $clModel    = new \App\Models\ConnLogs();
            $utModel    = new \App\Models\UsersTraffics();

            $userInfo   = $suModel->getByUsername($username);
            $serverInfo = $sModel->getServerByIp($serverIp);

            if ($userInfo && $serverInfo) {
                $userId     = $userInfo->user_id;
                $serverId   = $serverInfo->id;
                $uoModel    = new \App\Models\UsersOnline();

                $traffic    = $utModel->getUserTraffic($userId);
                $download   = $data["bytes_received"];
                $upload     = $data["bytes_sent"];

                $download   = round($download / (1024 * 1024), 2);
                $upload     = round($upload / (1024 * 1024), 2);
                $total      = $download + $upload;

                $trafficColumn = [
                    "upload"    => $upload,
                    "download"  => $download,
                    "total"     => $total,
                    "user_id"   => $userId,
                ];

                if ($traffic) {
                    $trafficColumn["upload"]    += $traffic->upload;
                    $trafficColumn["download"]  += $traffic->download;
                    $trafficColumn["total"]     += $traffic->total;
                    $trafficColumn["utime"]     = time();
                } else {
                    $trafficColumn["ctime"]     = time();
                    $trafficColumn["utime"]     = 0;
                }


                \App\Models\UsersTraffics::updateOrCreate(["id" =>  $traffic->id], $trafficColumn);
                $uoModel->removeOnlineUser($userId, $serverId, $pid);
                $clModel->addLogoutTime($userId, $serverId, $pid);
            }
        }
    }

    public function ovpnUtraffic($request, $response, $args)
    {
        $pdata  = $request->getParsedBody();
        if (!empty($pdata["data"])) {

            $log                = base64_decode($pdata["data"]);
            $clientListStart    = strpos($log, "OpenVPN CLIENT LIST") + strlen("OpenVPN CLIENT LIST") + 1;
            $clientListEnd      = strpos($log, "ROUTING TABLE");
            $clientListContent  = substr($log, $clientListStart, $clientListEnd - $clientListStart);

            $clientListLines    = explode("\n", $clientListContent);
            $clientListLines    = array_filter($clientListLines);

            if (!empty($clientListLines)) {
                $clientListHeader   = explode(",", $clientListLines[1]);

                $clientListEntries = [];
                for ($i = 2; $i < count($clientListLines); $i++) {
                    $entry = explode(",", $clientListLines[$i]);
                    if (count($clientListHeader) == count($entry)) {
                        $clientListEntries[] = array_combine($clientListHeader, $entry);
                    }
                }

                $onlineUsers = array_filter($clientListEntries);


                if (!empty($onlineUsers)) {
                    $uoModel    = new \App\Models\UsersOnline();

                    foreach ($onlineUsers as $client) {
                        $username   = $client["Common Name"];
                        $address    = $client["Real Address"];
                        $addressArr = explode(":", $address);
                        $userPid    = $addressArr[1];

                        $userInfo   = $uoModel->getOnlineUserInfo($username, $userPid);
                        if ($userInfo) {
                            $userId     = $userInfo->id;
                            \App\Models\UsersOnline::where([
                                "user_id"   => $userId,
                                "pid"       => $userPid
                            ])->update(["last_activity" => time()]);
                        }
                    }
                }
            }
        }
    }

    public function confirmInstalled($request, $response, $args)
    {
        $serverIp   = !empty($_SERVER["REMOTE_ADDR"]) ? $_SERVER["REMOTE_ADDR"] : "";
        $sModel     = new \App\Models\Servers();
        $serverInfo = $sModel->getServerByIp($serverIp);
        $setup      = $request->getQueryParam('setup');


        if ($serverInfo && !empty($setup)) {
            $serverId = $serverInfo->id;
            if ($setup == "main") {
                $sModel->doConfiguration($serverId);
            } else {
                $metaColumn = ["installed_$setup" => 1];
                $sModel->saveMeta($serverId, $metaColumn);
            }
        }
    }

    public function v2rayTraffic($request, $response, $args)
    {
        $pdata      = $request->getParsedBody();
        $serverIp   = !empty($_SERVER["REMOTE_ADDR"]) ? $_SERVER["REMOTE_ADDR"] : "";

        if (!empty($pdata["data"])) {
            $data           = $pdata["data"];
            $data           = json_decode(base64_decode($data), true);

            $sModel         = new \App\Models\Servers();
            $usModel        = new \App\Models\Subscribers();
            $clModel        = new \App\Models\ConnLogs();
            $utModel        = new \App\Models\UsersTraffics();
            $uoModel        = new \App\Models\UsersOnline();
            $seModel        = new \App\Models\Settings();
            $serverInfo     = $sModel->getServerByIp($serverIp);

            if (!empty($data) && $serverInfo) {
                $users = [];
                foreach ($data as $item) {
                    $username       = $item["u"];
                    $trafficType    = isset($item['dl']) ? "dl" : "up";
                    $value          = $item[$trafficType];
                    $users[$username][$trafficType] = $value;
                }

           
                //v2ray traffic coefficient
                $v2Settings  = $seModel->getSetting("servers_v2ray");
                $tcoefficient = getArrayValue($v2Settings, "traffic_coefficient", "");
                $tcoefficient = $tcoefficient ? $tcoefficient : 1;
       
                foreach ($users as $username => $values) {
                    $uplink     = !empty($values["up"]) ? $values["up"] : 0;
                    $download   = !empty($values["dl"]) ? $values["dl"] : 0;
                    $userInfo   = $usModel->getUserServerLogin($username);

                    if ($userInfo) {
                        $validityDays   = $userInfo->validity_days;
                        $userId         = $userInfo->user_id;
                        $endDate        = $userInfo->end_time;
                        $serverId       = $serverInfo->id;

                        if ($uplink || $download) {
                            $download   = round($download / (1024 * 1024), 2);
                            $uplink     = round($uplink / (1024 * 1024), 2);
                            $traffic    = $utModel->getUserTraffic($userId);
                            //$download   = round($download / $tcoefficient);
                            //$uplink     = round($uplink / $tcoefficient);

                            $trafficColumn = [
                                "upload"    => $uplink,
                                "download"  => $download,
                                "total"     => $uplink + $download,
                                "user_id"   => $userId,
                            ];

                            $trafficId = 0;
                            if ($traffic) {
                                $trafficId = $traffic->id;
                                $trafficColumn["upload"]    += $traffic->upload;
                                $trafficColumn["download"]  += $traffic->download;
                                $trafficColumn["total"]     += $traffic->total;
                                $trafficColumn["utime"]     = time();
                            } else {
                                $trafficColumn["ctime"]     = time();
                                $trafficColumn["utime"]     = 0;
                            }

                            \App\Models\UsersTraffics::updateOrCreate(["id" =>  $trafficId], $trafficColumn);


                            if ($uplink > 0 || $download > 0) {
                                \App\Models\UsersOnline::where([
                                    "user_id"   => $userId,
                                ])->update(["last_activity" => time()]);
                            }

                            $checkOnlien = $uoModel->checkV2rayOnline($userId);
                            if (!$checkOnlien) {
                                //add online
                                $uoModel->addOnlineUser($userId, $serverId, "", "", "", "v2ray");
                                $clModel->addLoginTime($userId, $serverId, "", "v2ray");
                            }
                        }


                        // for first login
                        if (!$userInfo->start_time) {
                            $usuModel   = new \App\Models\UsersSubs();
                            $startDate  = date("Y/m/d H:i:s");
                            $endDate    = date('Y/m/d H:i:s', strtotime($startDate . " + $validityDays days"));

                            $usuModel->setEndTime($userId, $startDate, $endDate);
                        }
                    }
                }
            }
        }
    }
}
