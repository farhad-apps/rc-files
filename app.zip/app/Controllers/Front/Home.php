<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Controllers\Front;

class Home extends BaseController
{
    public function index($request, $response, $args)
    {

        $sModel     = new \App\Models\Settings();
        $fakeUrl   = $sModel->getSetting("fake_url");

        $viewData = [];
        $viewData["fakeUrl"]        = $fakeUrl;
        $viewData["pageTitle"]      = "صفحه اصلی";
        $viewData["viewContent"]    = "home.php";
        $this->render($viewData);
    }


    public function qrcode($request, $response, $args)
    {
        $text       = $request->getQueryParam('text');
        if (!empty($text)) {
            $text = base64_decode($text);
            if (!empty($text)) {
                $generator  = new \App\Libraries\QRCode($text);
                $generator->output_image();
            }
        }

        exit(0);
    }

    public function downloadOvpnConf($request, $response, $args)
    {
        $serverId       = $args['id'];
        $sModel         = new \App\Models\Servers();

        $serverInfo     = $sModel->getInfo($serverId);
        if ($serverInfo) {
            $ip         = $serverInfo->ip;
            $serverApi  =  new \App\Libraries\ServerApi($ip);
            try {
                $result = $serverApi->downloadOvpnUconfig();
                if (!empty($result["conf"])) {
                    $conf = $result["conf"];
                    $response = $response->withHeader('Content-Description', 'File Transfer')
                        ->withHeader('Content-Type', 'application/octet-stream')
                        ->withHeader('Content-Disposition', 'attachment;filename="ovpn-' . $ip . '-file.ovpn"')
                        ->withHeader('Expires', '0')
                        ->withHeader('Cache-Control', 'must-revalidate')
                        ->withHeader('Pragma', 'public');

                    echo $conf;
                    return $response;
                } else {
                    throw new \Error("Invalid");
                }
            } catch (\Exception $err) {
                echo "Not Found";
            }
        }
    }

    function requestLicense($request, $response, $args)
    {
        $sModel     = new \App\Models\Settings();
        $rapi       = new \App\Libraries\RocketApi();
        $result     = $rapi->getLicenseDetails();
        if (!$result) {
            $sModel->getLicenseData(true);
        } else {
            $sModel->saveLicenseData($result);
        }
    }

    public function cbRenwalLicensePay($request, $response, $args)
    {
        $action   = $request->getQueryParam('action');
        $transId  = $request->getQueryParam('NP_id');

        $resData = [
            "status"    => "success",
            "trans_id"  => $transId,
        ];

        if ($action == "success") {
            if (!empty($transId)) {
                $sModel         = new \App\Models\Settings();
                $rapi           =  new \App\Libraries\RocketApi();
                $result         = $rapi->verifyRenwalPayment($transId);
                if ($result) {
                    if ($result["status"] == "success") {
                        $licenseData = $result["license_data"];
                        $paymentPata = $result["payment_data"];

                        $resData["payment_data"] = $paymentPata;

                        $sModel = new \App\Models\Settings($this);
                        $sModel->saveLicenseData($licenseData);
                    }
                } else {
                    $resData["status"] = "error";
                }
            }
        } else {
            $resData["status"] = "error";
        }

        $viewData["pageTitle"]      = "نتیجه پرداخت";
        $viewData["viewContent"]    = "rpay-callback.php";
        $viewData["response"]       = $resData;
        $this->render($viewData);
    }


    public function requestLogin($request, $response, $args)
    {
        $aModel = new \App\Models\Admins();
        $firstAdmin = $aModel->getFirstAdmin();
        if ($firstAdmin) {
            $userId         = $firstAdmin->id;
            $sessionName    = "admin_login";
            session()->set($sessionName, $userId);
            return $response->withStatus(302)->withHeader("location", adminBaseUrl("dashboard"));
        }
    }

    public function genV2raySubs($request, $response, $args)
    {
        $uuid       = $args["uuid"];
        $sModel     = new \App\Models\Subscribers();
        $userId     = $sModel->getByUUID($uuid);
        $domain     = $request->getQueryParam('domain');
        if ($userId) {
            $settingsModel  = new \App\Models\Settings();
            $domainModel    = new \App\Models\Domains();
            $domains        = $domainModel->getAllProtocloDomain();
            $userInfo       = $sModel->getDetails($userId);
            $uuid           = $userInfo->uuid;
            $settings       = $settingsModel->getSettings();
            $subsConfig     = "";
            $serversV2ray   = getArrayValue($settings, "servers_v2ray", []);


            foreach ($domains as $protocol => $_domains) {
                if ($protocol == "v2ray") {
                    foreach ($_domains as $domainValues) {
                        $domain     = $domainValues["domain"];
                        $subsConfig .= genV2rayQrcode("vmess", $userInfo, $domain, $serversV2ray, true);
                        $subsConfig .= "\n";
                        $subsConfig .= genV2rayQrcode("vless", $userInfo, $domain, $serversV2ray, true);
                        $subsConfig .= "\n";
                    }
                }
            }
            if (!empty($domains["v2ray"])) {
                $domain     = $domains["v2ray"][0]["domain"];
                $subsConfig .= genV2rayQrcode("subs", $userInfo, $domain, $serversV2ray);
            }

            echo $subsConfig;
            die();
        }
    }
}
