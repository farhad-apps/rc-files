<?php
$serverValues       = isset($formValues) ? $formValues : null;
$name               = getArrayValue($serverValues, "name");
$ip                 = getArrayValue($serverValues, "ip");
?>

<div class="modal-dialog modal-md modal-dialog-scrollable">
    <div class="modal-content">
        <div class="modal-header">
            <h6 class="modal-title">
                مشاهده وضعیت فیلترینگ [<?= $name ?>]
            </h6>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <div id="result-filtering"></div>
        </div>
    </div>
</div>
<script>
    var serverHost = "<?= $ip ?>:<?= $sshPort ?>";
    window.initCheckFiltering(serverHost);
</script>