<?php
$serverValues       = isset($formValues) ? $formValues : null;
$serverId           = getArrayValue($serverValues, "id");
$name               = getArrayValue($serverValues, "name");
$ip                 = getArrayValue($serverValues, "ip");
$sshUser            = getArrayValue($serverValues, "ssh_user");
$sshPass            = getArrayValue($serverValues, "ssh_pass");
$sshPort            = getArrayValue($serverValues, "ssh_port", 22);
$categoryId         = getArrayValue($serverValues, "category_id", 0);
$limitUsers         = getArrayValue($serverValues, "limit_online_users");
$countryCode        = getArrayValue($serverValues, "country_code");
$ovpnSubdomain      = getArrayValue($serverValues, "ovpn_subdomain");
$protocols          = getArrayValue($serverValues, "protocols", []);
$sshCategory        = getArrayValue($serverValues, "ssh_category");
$openvpnCategory    = getArrayValue($serverValues, "openvpn_category");
$v2rayCategory      = getArrayValue($serverValues, "v2ray_category");
$installedSsh       = getArrayValue($serverValues, "installed_ssh");
$installedOpenvpn   = getArrayValue($serverValues, "installed_openvpn");
$installedV2ray     = getArrayValue($serverValues, "installed_v2ray");

$formMethod         = $serverId ? "put" : "post";
$formAction         = $serverId ? adminBaseUrl("ajax/servers/$serverId") : adminBaseUrl("ajax/servers");

$checkedSsh         = in_array("ssh", $protocols);
$checkedOvpn        = in_array("openvpn", $protocols);
$checkedV2ray       = in_array("v2ray", $protocols);
?>

<div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title">
                <?= $serverId  ? "ویرایش سرور" : "افزودن سرور" ?>
            </h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <form id="servers-form" method="<?= $formMethod ?>" action="<?= $formAction ?>">
                <div class="row g-2">
                    <div class="col-lg-6">
                        <div class="card border">
                            <div class="card-header">اطلاعات سرور</div>
                            <div class="card-body">
                                <div class="form-group mb-1">
                                    <label for="name" class="form-label dir-ltr">نام سرور</label>
                                    <input type="text" value="<?= $name ?>" name="name" class="form-control" placeholder="عنوان سرور را وارد کنید (مثلا: هلند ۱)" required>
                                </div>

                                <div class="form-group mb-1">
                                    <label for="name" class="form-label dir-ltr">کشور</label>
                                    <select class="form-select" name="country_code" required>
                                        <option value="">انتخاب کنید</option>
                                        <?php foreach ($countries as $code => $country) { ?>
                                            <option value="<?= $code ?>" <?= $countryCode == $code ? "selected" : "" ?>><?= $country ?></option>
                                        <?php } ?>
                                    </select>
                                </div>

                                <div class="form-group mb-1">
                                    <label for="ip" class="form-label dir-ltr">آیپی سرور</label>
                                    <input type="text" value="<?= $ip ?>" name="ip" class="form-control text-end dir-ltr" dir="ltr" placeholder="e.g. 195.201.148.234" required>
                                </div>

                                <div class="form-group mb-1">
                                    <label for="ssh_username" class="form-label dir-ltr">SSH نام کاربری</label>
                                    <input type="text" value="<?= $sshUser ?>" name="ssh_user" class="form-control text-end dir-ltr" dir="ltr" placeholder="e.g. root" required>
                                </div>

                                <div class="form-group mb-1">
                                    <label for="ip" class="form-label dir-ltr">SSH رمز عبور</label>
                                    <input type="text" value="<?= $sshPass ?>" name="ssh_pass" class="form-control text-end dir-ltr" dir="ltr" placeholder="Enter ssh password" required>
                                </div>

                                <div class="form-group mb-1">
                                    <label for="ssh_username" class="form-label dir-ltr">SSH پورت</label>
                                    <input type="number" value="<?= $sshPort ?>" name="ssh_port" readonly class="form-control text-end dir-ltr" dir="ltr" placeholder="e.g. 22" required>
                                </div>
                                <div class="form-group mb-1">
                                    <label for="ssh_username" class="form-label dir-ltr">محدودیت آنلاین ها (0 نامحدود)</label>
                                    <input type="number" value="<?= $limitUsers ?>" name="limit_online_users" class="form-control" placeholder="محدودیت آنلاین ها را وارد کنید...">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="card border">
                            <div class="card-header">انتخاب پروتکل ها</div>
                            <div class="card-body">
                                <div class="form-group mt-2">
                                    <div class="protocol-check mb-2 pb-3 border-bottom <?= $installedSsh ? "disabled-protocol" : "" ?>" >
                                        <div class="form-check">
                                            <input class="form-check-input protocols" <?= $checkedSsh ? "checked" : "" ?> name="protocols[]" type="checkbox" value="ssh" required>
                                            <label class="form-check-label">
                                                پروتکل SSH
                                            </label>
                                        </div>
                                        <div class="protocol-category form-group" style="display: <?= $checkedSsh ? "" : "none" ?>;">
                                            <label class="form-label fw-normal">انتخاب دسته بندی</label>
                                            <select class="form-select" name="ssh_category">
                                                <option value="">بدون دسته بندی</option>
                                                <?php
                                                if ($categories) {
                                                    foreach ($categories as $category) {
                                                        if ($category->protocol == "ssh") {
                                                            $selected = $category->id == $sshCategory ? "selected" : "";
                                                ?>
                                                            <option <?= $selected ?> value="<?= $category->id ?>"><?= $category->name ?></option>
                                                <?php
                                                        }
                                                    }
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>
                                    <?php if (in_array("openvpn", $licenseData["active_protocols"])) { ?>
                                        <div class="protocol-check mb-2 pb-3 border-bottom <?= $installedOpenvpn ? "disabled-protocol" : "" ?>">
                                            <input class="form-check-input protocols" name="protocols[]" <?= $checkedOvpn ? "checked" : "" ?> type="checkbox" value="openvpn" required>
                                            <label class="form-check-label">
                                                پروتکل OPEVVPN
                                            </label>
                                            <div class="protocol-category form-group" style="display: <?= $checkedOvpn ? "" : "none" ?>;">
                                                <label class="form-label fw-normal">انتخاب دسته بندی</label>
                                                <select class="form-select" name="openvpn_category">
                                                    <option value="">انتخاب کنید</option>
                                                    <?php
                                                    if ($categories) {
                                                        foreach ($categories as $category) {
                                                            if ($category->protocol == "openvpn") {
                                                                $selected = $category->id == $openvpnCategory ? "selected" : "";
                                                    ?>
                                                                <option <?= $selected ?> value="<?= $category->id ?>"><?= $category->name ?></option>
                                                    <?php
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    <?php } ?>
                                    <?php if (in_array("v2ray", $licenseData["active_protocols"])) { ?>
                                        <div class="protocol-check mb-2 <?= $installedV2ray ? "disabled-protocol" : "" ?>">
                                            <div class="form-check">
                                                <input class="form-check-input protocols" <?= $checkedV2ray ? "checked" : "" ?> name="protocols[]" type="checkbox" value="v2ray" required>
                                                <label class="form-check-label">
                                                    پروتکل v2ray (هسته xray)
                                                </label>
                                            </div>
                                            <div class="protocol-category form-group" style="display: <?= $checkedV2ray ? "" : "none" ?>;">
                                                <label class="form-label fw-normal">انتخاب دسته بندی</label>
                                                <select class="form-select" name="v2ray_category">
                                                    <option value="">انتخاب کنید</option>
                                                    <?php
                                                    if ($categories) {
                                                        foreach ($categories as $category) {
                                                            if ($category->protocol == "v2ray") {
                                                                $selected = $category->id == $v2rayCategory ? "selected" : "";
                                                    ?>
                                                                <option <?= $selected ?> value="<?= $category->id ?>"><?= $category->name ?></option>
                                                    <?php
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    <?php } ?>
                                    <div class="form-check-error"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <div class="modal-footer justify-content-between">
            <div class="text-muted small">
                <div> توجه داشته باشد سیستم عامل نصب شده حتما باید Ubuntu 22.04 باشد.</div>
                <div> پورت پیش فرض سرور یعنی 22 هیچ وقت غیر فعال نشود.</div>
                <div>بعد از اضافه شدن سرور وضعیت آن به صورت غیر فعال است. پس از کانفیگ و سینک کاربران آنرا به صورت دستی فعال کنید.</div>
            </div>
            <button class="btn btn-primary btn-float-icon" id="btn-submit-server" form='servers-form'>
                <?= inlineIcon("save") ?>
                <?= $serverId ? " ویرایش سرور" : " افزودن سرور" ?>
            </button>
        </div>
    </div>
</div>


<script>
    var formMode = "<?= !$serverId ? "add" : "edit" ?>";
    window.initServersForm(formMode);
</script>