<div class="row justify-content-center mb-3">
    <div class="col-lg-6 text-center">
        <div class="card border-0">
            <div class="card-body p-1">
                <div class="fs-3 text-primary">
                    <?= inlineIcon("users") ?>
                </div>
                <h6 class="fw-bold text-primary mb-3">تعداد کاربران سرور</h6>
                <div id="server-users-count">
                    <h4>0</h4>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6 text-center">
        <div class="card border-0">
            <div class="card-body p-1">
                <div class="fs-3 text-warning">
                    <?= inlineIcon("users-rectangle") ?>
                </div>
                <h6 class="fw-bold text-warning mb-3">تعداد کاربران فعال پنل</h6>
                <h4><?= $activeUsers ?></h4>
            </div>
        </div>
    </div>
</div>
<div class="text-center">
    <div class="bd-callout bd-callout-info p-2 my-1 mb-3" role="alert">
        اگر تعداد کاربران پنل و سررو با هم یکی نباشند نیاز به سینک کردن کاربران پنل با سرور دارید
    </div>
    <button class="btn btn-primary btn-float-icon" id="btn-sycn-users" data-id="<?= $serverId ?>">
        <?= inlineIcon("refresh") ?>
        سینک کاربران
    </button>
</div>