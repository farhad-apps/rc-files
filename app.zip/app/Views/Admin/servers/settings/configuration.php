<?php
$isConfigured   = getArrayValue($serverInfo, "is_configured");
if ($isConfigured) {
?>
    <div class="py-3">
        <div class="text-center">
            <h5 class="fw-bold text-warning mb-3"> کانفیگ سرور قبلا انجام شده است</h5>
            <h6 class="text-dark mb-4">آیا می خواهید دوباره این عملیات را انجام دهید؟</h6>
            <div class="bd-callout bd-callout-warning p-2 my-1 mb-4" role="alert">
                در نظر داشته باشید زمان این عملیات با توجه به نوع سیستم عامل شما ممکن متغیر باشد
                <br>
                <b> لطفا تا پایان عملیات از بستن مرورگر خود داری کنید!</b>
            </div>
            <button id="btn-configure" class="btn btn-primary btn-float-icon">
                <?= inlineIcon("arrows-rotate") ?>
                کانفیگ مجدد
            </button>
        </div>

    </div>
<?php
} else {
?>
    <div class="py-3">
        <div class="text-center">
            <h6 class="fw-bold mb-5 pb-2">
                برای نصب و کانفیگ سیستم عامل فقط کافیست دکمه زیر را کلیک کنید
            </h6>
            <div class="bd-callout bd-callout-warning p-2 my-1 mb-4 " role="alert">
                در نظر داشته باشید زمان این عملیات با توجه به نوع سیستم عامل شما ممکن متغیر باشد
                <br>
                <b> لطفا تا پایان عملیات از بستن مرورگر خود داری کنید!</b>
            </div>

            <button id="btn-configure" class="btn btn-primary btn-float-icon">
                <?= inlineIcon("code") ?>
                کانفیگ اولیه
            </button>
        </div>
    </div>
<?php
}
?>



<div class="modal" id="configure-modal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">کانفیگ سرور</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <h6>در حال نصب و راه اندازی سرور لطفا منتظر بمانید...</h6>
                <style>
                    .configure-console {
                        border: 2px solid var(--bs-modal-header-border-color);
                        padding: 10px;
                        overflow-y: scroll;
                        max-height: 400px;
                        width: 100%;
                        direction: ltr;
                        background: #030722;
                        color: #80deea;
                        border-radius: 7px;
                    }

                    .configure-console pre {
                        margin: 0;
                        white-space: pre-wrap;
                        overflow-wrap: break-word;
                        font-family: monospace;
                    }
                </style>
                <div class="configure-console">
                    <pre id="log-body"></pre>
                </div>
            </div>
        </div>
    </div>
</div>