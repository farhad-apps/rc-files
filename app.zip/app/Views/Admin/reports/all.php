<div class="card mb-3">
    <div class="card-header">
        مشترکان ثبت شده ۳۰ روز گذشته
    </div>
    <div class="card-body">
        <canvas id="subs-chart" style="width:100%;height: 300px;"></canvas>
    </div>
</div>

<?php
if ($userRole == "admin") {
?>
    <div class="card mb-3">
        <div class="card-header">
            مشترکان ثبت شده توسط نمایندگان
        </div>
        <div class="card-body">
            <canvas id="resellers-subs-chart" style="width:100%;height: 300px;"></canvas>
        </div>
    </div>
    <script>
        var resellersSubs = <?= json_encode($resellersSubs) ?>;
    </script>
<?php
}
?>

<script>
    var subsMonth = <?= json_encode($subsMonth) ?>;

</script>