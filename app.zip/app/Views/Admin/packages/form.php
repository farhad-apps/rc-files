<?php
$formValues         = isset($formValues) ? $formValues : null;

$packageId          = getArrayValue($formValues, "id");
$name               = getArrayValue($formValues, "name");
$validityDays       = getArrayValue($formValues, "validity_days");
$price              = getArrayValue($formValues, "price", "");
$traffic            = getArrayValue($formValues, "traffic");
$limitUsers         = getArrayValue($formValues, "limit_users");
$startTime          = getArrayValue($formValues, "start_time_type");
$isDisabled         = getArrayValue($formValues, "is_disabled", 0);

$formMethod         = $packageId ? "put" : "post";
$formAction         = $packageId ? adminBaseUrl("ajax/packages/$packageId") : adminBaseUrl("ajax/packages");
?>

<div class="modal-dialog modal-md">
    <div class="modal-content">
        <form id="package-form" method="<?= $formMethod ?>" action="<?= $formAction ?>">
            <div class="modal-header">
                <h5 class="modal-title">
                    <?= $packageId  ? "ویرایش پکیج" : "افزودن پکیج" ?>
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="form-group ">
                    <label for="name" class="form-label">نام پکیج</label>
                    <input type="text" value="<?= $name ?>" name="name" class="form-control" placeholder="نام پکیج را وارد کنید" required>
                </div>

                <div class="form-group mb-2">
                    <label for="validity_days" class="form-label">مدت اعتبار <span class="fw-normal text-muted">(صفر به معنای نامحدود)</span></label>
                    <div class="input-group">
                        <input type="number" min="0" value="<?= $validityDays ?>" name="validity_days" class="form-control" placeholder="تعداد روزهای فعالی را وارد کنید" required> <span class="input-group-text">روز</span>
                    </div>
                </div>

                <div class="form-group mb-2">
                    <label for="traffic" class="form-label">مقدار ترافیک <span class="fw-normal text-muted">(صفر به معنای نامحدود)</span></label>
                    <div class="input-group">
                        <input type="number" value="<?= $traffic ?>" name="traffic" min="0" class="form-control" placeholder="مقدار ترافیک قابل مصرف را وارد کنید" required>
                        <span class="input-group-text">گیگابایت</span>
                    </div>
                </div>

                <div class="form-group ">
                    <label for="price" class="form-label">قیمت (تومان)</label>
                    <input type="text" data-separator="true" value="<?= $price ? number_format($price) : '' ?>" name="price" class="form-control" placeholder="قیمت پکیج را وارد کنید" required>
                </div>
                <div class="form-group ">
                    <label for="limit_users" class="form-label">تعداد کاربر همزمان</label>
                    <input type="number" min="0" value="<?= $limitUsers ?>" name="limit_users" class="form-control" placeholder="تعداد کاربرهای همزمان را وارد کنید" required>
                </div>
                <div class="form-group ">
                    <label for="start_time_type" class="form-label">زمان شروع با</label>
                    <select class="form-select" name="start_time_type" required>
                        <option value="">انتخاب کنید</option>
                        <option value="first-conn" <?= $startTime == "first-conn" ? "selected" : "" ?>>اولین اتصال کاربر</option>
                        <option value="create-user" <?= $startTime == "create-user"  ? "selected" : "" ?>>ساخت کاربر</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="is_disabled" class="form-label">وضعیت</label>
                    <select class="form-select" name="is_disabled" required>
                        <option value="0" <?= $isDisabled == 0 ? "selected" : "" ?>>فعال</option>
                        <option value="1" <?= $isDisabled == 1  ? "selected" : "" ?>>غیر فعال</option>
                    </select>
                </div>
            </div>
            <div class=" modal-footer">
                <button class="btn btn-primary btn-float-icon" type="submit">
                    <?= inlineIcon("save") ?>
                    <?= $packageId ? " ویرایش پکیج" : " افزودن پکیج" ?>
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    var formMode = "<?= !$packageId ? "add" : "edit" ?>";
    window.initPackageForm(formMode);
</script>