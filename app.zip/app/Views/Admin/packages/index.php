<div class="custome-breadcrumb has-actions">
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= adminBaseUrl("dashboard") ?>">داشبورد</a></li>
            <li class="breadcrumb-item"><a href="<?= adminBaseUrl("packages") ?>">پکیج ها</a></li>
            <li class="breadcrumb-item active">لیست</li>
        </ol>
    </nav>
    <div class="actions">
        <button class="btn btn-primary btn-ajax-views btn-float-icon" data-url="packages/add">
            <?= inlineIcon("add", "icon") ?>
            افزودن
        </button>
    </div>
</div>
<div class="card">
    <div class="card-body p-0 py-3">
        <div class="card-datatable table-responsive">
            <table id="packages-table" class="table table-striped" style="width: 100%;">
                <tbody>

                </tbody>
            </table>
        </div>
    </div>
</div>