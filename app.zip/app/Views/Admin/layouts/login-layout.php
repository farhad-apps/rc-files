<?php include "sections/head.php"; ?>
    <?php include adminViewContents($viewContent); ?>
<?php include "sections/footer.php"; ?>