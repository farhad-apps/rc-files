<div class="sidebar-panel">
    <div class="d-flex flex-column flex-shrink-0 h-100">
        <div class="logo-wrapper">
            <img src="<?= $siteLogo ?>" width="55" class="mb-2" />
        </div>
        <div class="main-content">
            <ul class="nav flex-column mb-auto menu">
                <li class="nav-item">
                    <a href="<?= adminBaseUrl("dashboard") ?>" class="nav-link <?= $activeMenu == "dashboard" ? "active" : "link-body-emphasis" ?>">
                        <?= inlineIcon("dashboard", "menu-icon") ?>
                        داشبورد
                    </a>
                </li>
                <li>
                    <a href="<?= adminBaseUrl("subscribers") ?>" class="nav-link <?= $activeMenu == "subscribers" ? "active" : "link-body-emphasis" ?>">
                        <?= inlineIcon("users", "menu-icon") ?>
                        مدیریت مشترکین
                    </a>
                </li>

                <?php if ($userRole == "admin") { ?>

                    <li>
                        <a href="<?= adminBaseUrl("servers") ?>" class="nav-link <?= $activeMenu == "servers" ? "active" : "link-body-emphasis" ?>">
                            <?= inlineIcon("server", "menu-icon") ?>
                            مدیریت سرورها
                        </a>
                    </li>
                    <li>
                        <a href="<?= adminBaseUrl("packages") ?>" class="nav-link <?= $activeMenu == "packages" ? "active" : "link-body-emphasis" ?>">
                            <?= inlineIcon("layer-group", "menu-icon") ?>
                            مدیریت پکیج ها
                        </a>
                    </li>
                    <li>
                        <a href="<?= adminBaseUrl("resellers") ?>" class="nav-link <?= $activeMenu == "resellers" ? "active" : "link-body-emphasis" ?>">
                            <?= inlineIcon("user-group", "menu-icon") ?>
                            مدیریت نمایندگان
                        </a>
                    </li>
                    <li>
                        <a href="<?= adminBaseUrl("admins") ?>" class="nav-link <?= $activeMenu == "admins" ? "active" : "link-body-emphasis" ?>">
                            <?= inlineIcon("user-group-crown", "menu-icon") ?>
                            کاربران مدیر
                        </a>
                    </li>
                    <li>
                        <a href="<?= adminBaseUrl("settings") ?>" class="nav-link <?= $activeMenu == "settings" ? "active" : "link-body-emphasis" ?>">
                            <?= inlineIcon("gear", "menu-icon") ?>
                            تنظیمات
                        </a>
                    </li>
                <?php } ?>
                <li>
                    <a href="<?= adminBaseUrl("reports") ?>" class="nav-link <?= $activeMenu == "reports" ? "active" : "link-body-emphasis" ?> ">
                        <?= inlineIcon("chart-simple", "menu-icon") ?>
                        گزارشات
                    </a>
                </li>
                <li>
                    <a href="<?= adminBaseUrl("logout") ?>" class="nav-link link-body-emphasis ">
                        <?= inlineIcon("power-off", "menu-icon") ?>
                        خروج
                    </a>
                </li>
            </ul>
            <div class="text-center p-2 ">
                <span class="badge bg-primary text-white py-2">Version <?= $appVersion ?></span>
            </div>
        </div>
    </div>

    <div class="switch-overlay"></div>
</div>