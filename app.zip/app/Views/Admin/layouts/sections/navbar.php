<?php
$expiredTime        = $licenseData["expire_time"];
$currentPlan        = $licenseData["plan_name"];
?>
<nav class="navbar navbar-expand-md navbar-light default">
    <div class="container-fluid p-0">
        <div class="d-flex justify-content-between w-100">
            <div class="header-toggle d-block d-lg-none ">
                <button class="menu-toggle bt-sm  btn btn-primary ">
                    <?= inlineIcon("bars", "align-middle") ?>
                </button>
            </div>

            <div class="d-flex align-items-center">
                <div class="ps-2"> <?= $userInfo["role_name"] ?>: <?= $userInfo["full_name"] ?></div>
            </div>
            <div class="m-auto"></div>
            <div class="navbar-items">
                <div class="item d-none d-sm-flex navbar-items">
                    <?php if ($userInfo['role'] == "reseller") { ?>
                        <?php
                        $unlimited = $userInfo["unlimited"];
                        if ($unlimited) {
                        ?>
                            <div class="item">اعتبار: نامحدود</div>
                        <?php
                        } else {
                        ?>
                            <div class="item">اعتبار: <span id="spn-credit"><?= number_format($userInfo["credit"]) ?></span> تومان</div>
                        <?php
                        }
                        ?>

                    <?php } else { ?>
                        <div class="item">
                            <span data-bs-toggle="tooltip" title="<?= translateLicense($currentPlan) ?>"  data-bs-placement="bottom"  class="licence-tag cursor-pointer bg-<?= $currentPlan ?>"></span>
                            اعتبار لایسنس: <?= $expiredTime ? translateDiffTime($expiredTime) : "نامحدود" ?>

                        </div>
                        <div class="item">امروز: <?= getCurrentDate() ?></div>
                    <?php } ?>
                </div>
                <div class="item d-flex">
                    <button type="button" class="btn btn-link nav-link btn-toggle-color dropdown-toggle" data-bs-toggle="dropdown">
                        <span class="preset-color" data-value="<?= $activeColor ?>"></span>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end border">
                        <div class="preset-colors">
                            <?php
                            for ($x = 1; $x <= 10; $x++) {
                            ?>
                                <span class="preset-color" data-value="preset-<?= $x ?>"></span>
                            <?php
                            }
                            ?>
                        </div>
                    </ul>
                </div>
                <div class="item">
                    <button type="button" id="btn-toggle-theme" class="btn border btn-toggle-theme btn-sm" data-theme="<?= $activeTheme ?>" aria-pressed="false">
                        <?= inlineIcon($activeTheme == "light" ? "sun" : "moon-stars") ?>
                    </button>
                </div>

            </div>
        </div>
        <div class="d-block d-sm-none w-100">
            <div class="navbar-items small mt-1 justify-content-center ">
                <?php if ($userInfo['role'] == "reseller") { ?>
                    <?php
                    $unlimited = $userInfo["unlimited"];
                    if ($unlimited) {
                    ?>
                        <div class="item">اعتبار: نامحدود</div>
                    <?php
                    } else {
                    ?>
                        <div class="item">اعتبار: <span id="spn-credit"><?= number_format($userInfo["credit"]) ?></span> تومان</div>
                    <?php
                    }
                    ?>

                <?php } else { ?>
                    <div class="item">
                        <span class="licence-tag bg-<?= $currentPlan ?>"></span>
                        اعتبار لایسنس: <?= $expiredTime ? translateDiffTime($expiredTime) : "نامحدود" ?>

                    </div>
                    <div class="item">امروز: <?= getCurrentDate() ?></div>
                <?php } ?>
            </div>
        </div>
    </div>
</nav>