<?php include "sections/head.php"; ?>
<?php include "sections/sidemenu.php"; ?>

<div class="container-fluid h-100">
    <div class="main-content-wrap d-flex flex-column h-100">
        <?php include "sections/navbar.php"; ?>
        <div class="flex-shrink-0 mb-2">
            <div class="main-content pt-2">
                <?php if ($licenseData["is_active"] && $licenseData["plan_name"] == "free") { ?>
                    <div class="alert alert-warning p-2 px-3">
                        پلن پیشفرض شما رایگان هست, این پلن تا <?= translateDiffTime($licenseData["expire_time"]) ?> فعال است.
                    </div>
                <?php } ?>
                <?php include adminViewContents($viewContent); ?>
            </div>
        </div>

        <?php if ($showUpNotice || !empty($footerText)) { ?>
            <footer class="footer mt-auto py-1 border-top mb-2">
                <div class="container-fluid p-0">
                    <div class="row ">
                        <div class="col-lg-6">
                            <?php if ($showUpNotice) { ?>
                                <small class="text-primary">
                                    ورژن جدیدی از نرم افزار قابل درسترس است.
                                </small>
                                <a class="text-dark small" href="<?= baseUrl("update.php") ?>">
                                    کلیک کنید
                                    <?= inlineIcon("square-arrow-up-right") ?>
                                </a>
                            <?php } ?>
                        </div>
                        <?php if ($licenseData["plan_name"] != "brillant") { ?>
                            <div class="col-lg-6 text-end small">
                                Rocket SSH Pro By <a target="_blank" href="https://github.com/rocket-ap">Mahmoud AP</a>
                                Version <?= $appVersion ?>
                                |
                                <a target="_blank" class="ms-3" href="https://t.me/rocket_ssh_pro">
                                    Telegram
                                </a>
                            </div>
                        <?php } else { ?>
                            <div class="col-lg-6 text-end small">
                                <?= $footerText ?>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </footer>
        <?php } ?>
    </div>
</div>

<?php include "sections/footer.php"; ?>