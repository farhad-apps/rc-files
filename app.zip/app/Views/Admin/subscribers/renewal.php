<?php
$userId             = getArrayValue($userValues, "user_id");
$username           = getArrayValue($userValues, "username");
$password           = getArrayValue($userValues, "password");
$mobile             = getArrayValue($userValues, "mobile");
$desc               = getArrayValue($userValues, "desc");
$packageId          = getArrayValue($userValues, "package_id");
$startTime          = getArrayValue($userValues, "start_time");
$endTime            = getArrayValue($userValues, "end_time");
$limitUsers         = getArrayValue($userValues, "limit_users");
$traffic            = getArrayValue($userValues, "traffic");
$validityDays       = getArrayValue($userValues, "validity_days");
$cname              = getArrayValue($userValues, "cname", "");
$crole              = getArrayValue($userValues, "crole", "");
$ccredit            = getArrayValue($userValues, "ccredit", 0);
$cunlimited         = getArrayValue($userValues, "cunlimited", 0);

$disabledSubmit = "";
if ($crole != "admin" && !$ccredit && !$cunlimited) {
    $disabledSubmit = "disabled";
}
?>
<form id="renewal-users-form" class="w-100 h-100" action="<?= adminBaseUrl("ajax/subscribers/$userId/renewal") ?>" method="put">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">تمدید کاربر [<?= $username ?>]</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="text-info fw-bold">در صورتی که مشترک غیر فعال باشد پس از تمدید فعال شده و میتواند از حساب کاربر خود استفاده کند.</div>
                <hr class="my-3" />
                <?php if ($userRole == "admin" && $crole != "admin" && !$cunlimited) { ?>
                    <div class="alert alert-warning p-2">
                        ایجاد کننده این مشترک [<?= $cname ?>] است.
                        اعتبار این نماینده در حال حاضر <?= number_format($ccredit) ?> تومان است.
                    </div>
                <?php } ?>

                <div class="form-group mb-2">
                    <label class="form-label">انتخاب پکیج</label>
                    <select class="form-select" name="package_id">
                        <option value="">انتخاب کنید</option>
                        <?php
                        if (!empty($packages)) {
                            foreach ($packages as $package) {
                                $trafficTitle =  $package->traffic ?  $package->traffic . " گیگابایت" : "نامحدود";
                                $packageData = base64_encode(json_encode($package));
                        ?>
                                <option data-values="<?= $packageData ?>" value="<?= $package->id ?>"><?= $package->name ?> - <?= $trafficTitle ?> - <?= $package->price ?> تومان</option>
                        <?php
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="my-2" id="sel-package-info" style="display: none;">

                </div>

                <?php if ($crole == "admin" || $cunlimited) { ?>
                    <div class="form-group" id="renewal-days-input">
                        <label>تعداد روزهای تمدید</label>
                        <input type="number" name="renewal_days" class="form-control" min="1" placeholder="تعداد روزهای تمدید را وارد کنید" required>
                    </div>
                <?php } ?>

                <div class="row">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>ثبت از امروز</label>
                            <div class="form-control">
                                <div class="form-check form-check-inline mb-0">
                                    <input class="form-check-input" type="radio" name="renewal_date" value="yes" required>
                                    <label class="form-check-label  mb-0">بلی</label>
                                </div>
                                <div class="form-check form-check-inline mb-0">
                                    <input class="form-check-input" type="radio" checked name="renewal_date" value="no" required>
                                    <label class="form-check-label  mb-0">خیر</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label>ریست کردن ترافیک</label>
                            <div class="form-control">
                                <div class="form-check form-check-inline mb-0">
                                    <input class="form-check-input" type="radio" name="renewal_traffic" value="yes" required>
                                    <label class="form-check-label  mb-0">بلی</label>
                                </div>
                                <div class="form-check form-check-inline mb-0">
                                    <input class="form-check-input" type="radio" checked name="renewal_traffic" value="no" required>
                                    <label class="form-check-label  mb-0">خیر</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="modal-footer">

                <button class="btn btn-primary" <?= $disabledSubmit ?> type="submit">
                    <?= inlineIcon("arrows-rotate") ?>
                    تمدید
                </button>
            </div>
        </div>
    </div>
</form>

<script>
    var isUnlimited = <?= $cunlimited ?>;
    window.initRenewalForm();
</script>