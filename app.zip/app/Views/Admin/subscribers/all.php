<style>
    tr.selected td {
        background-color: #efefef;
    }

    [data-bs-theme=dark] tr.selected td {
        background-color: var(--bs-body-bg) !important;
    }
</style>
<div class="card-header">
    <form id="filtering-form">
        <div class="row g-2">
            <div class="col-lg-2">
                <div class="form-group mb-1">
                    <label>جستجو</label>
                    <input type="search" name="main_search" class="form-control" placeholder="جستجو..." />
                </div>
            </div>
            <?php if ($userRole == "admin") { ?>
                <div class="col-6 col-lg-2">
                    <div class="form-group mb-1">
                        <label>ایجاد کننده</label>
                        <select name="creator" class="form-select">
                            <option value="">همه</option>
                            <?php if ($adminUsers) {
                                foreach ($adminUsers as $user) {
                            ?>
                                    <option value="<?= $user->id ?>"><?= $user->full_name ?> <?= $user->role != "admin" ? " (" . $user->role_name . ")" : "" ?></option>
                            <?php
                                }
                            } ?>
                        </select>
                    </div>
                </div>
            <?php } ?>
            <div class="col-6 col-lg-2">
                <div class="form-group mb-1">
                    <label>فیلتر انقضاء</label>
                    <select name="expiry_type" class="form-select">
                        <option value="">همه</option>
                        <option value="today">مشترکین منقضی شونده امروز</option>
                        <option value="3_days">مشترکین منقضی شونده سه روز آینده</option>
                        <option value="this_week">مشترکین منقضی شونده این هفته</option>
                    </select>
                </div>
            </div>
            <div class="col-6 col-lg-1">
                <div class="form-group mb-1">
                    <label>وضعیت کاربران</label>
                    <select name="status" class="form-select">
                        <option value="">همه</option>
                        <option value="active">فعال</option>
                        <option value="inactive">غیر فعال</option>
                    </select>
                </div>
            </div>
            <div class="col-6 col-lg-1">
                <div class="form-group mb-1">
                    <label>تعداد کاربر</label>
                    <select name="limit_users" class="form-select">
                        <option value="">همه</option>
                        <option value="single">تک کاربری</option>
                        <option value="multi">چند کاربری</option>
                    </select>
                </div>
            </div>
            <div class="col-6 col-lg-1">
                <div class="form-group mb-1">
                    <label> وضعیت اتصال</label>
                    <select name="conn_type" class="form-select">
                        <option value="">همه</option>
                        <option value="online">فقط آنلاین ها</option>
                        <option value="offline">فقط آفلاین ها</option>
                    </select>
                </div>
            </div>
        </div>
    </form>
</div>
<div class="card-datatable table-responsive">
    <table id="users-table" class="table" style="width: 100%;">
        <tbody>

        </tbody>
    </table>
</div>

<div class="modal" id="table-action-modal" tabindex="-1">
    <div class="modal-dialog modal-sm modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-6" id="exampleModalLabel">منوی مشترک <span id="sub-menu-uname"></span></h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-0">

            </div>
        </div>
    </div>
</div>

<script>
    var activeStatus = "<?= $activeStatus ?>";
    var tablePageLength = 25;
</script>