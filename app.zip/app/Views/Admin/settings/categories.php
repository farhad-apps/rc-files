<div class="row">
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                فرم افزودن
            </div>
            <div class="card-body">
                <form id="category-form" method="post" action="<?= adminBaseUrl("ajax/categories") ?>">
                    <div class="form-group">
                        <label>نام دسته بندی</label>
                        <input type="text" name="name" class="form-control" placeholder="نام دسته بندی را وارد کنید..." required />
                    </div>
                    <div class="form-group">
                        <label>انتخاب پروتکل</label>
                        <select class="form-select" name="protocol" required>
                            <option value="ssh">پروتکل SSH</option>
                            <option value="openvpn">پروتکل OPENVPN</option>
                            <option value="v2ray">پروتکل V2RAY</option>
                        </select>
                    </div>
                    <div class="mt-3">
                        <button type="submit" class="btn btn-primary btn-float-icon">
                            <?= inlineIcon("save") ?>
                            ذخیره
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                لیست دسته بندی ها
            </div>

            <div class="card-body p-0 py-3">
                <div class="card-datatable table-responsive">
                    <table id="categories-table" class="table table-striped" style="width: 100%;">
                        <tbody>

                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="modal fade" id="category-edit-modal">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    ویرایش دسته بندی [<span id="cat-title"></span>]
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="category-edit-form" method="put" action="">
                    <div class="form-group">
                        <label>نام دسته بندی</label>
                        <input type="text" name="name" class="form-control" placeholder="نام دسته بندی را وارد کنید..." required />
                    </div>
                    <div class="form-group">
                        <label>انتخاب پروتکل</label>
                        <select class="form-select" name="protocol" required>
                            <option value="ssh">پروتکل SSH</option>
                            <option value="openvpn">پروتکل OPENVPN</option>
                            <option value="v2ray">پروتکل V2RAY</option>
                        </select>
                    </div>
                    <div class="mt-3">
                        <button type="submit" class="btn btn-primary btn-float-icon">
                            <?= inlineIcon("save") ?>
                            ذخیره
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>