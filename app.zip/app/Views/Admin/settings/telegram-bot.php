<?php

$adminBotToken  = getArrayValue($adminBot, "token", "");
$adminChatId    = getArrayValue($adminBot, "chat_id", "");
?>
<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                ربات تلگرام مدیریت
            </div>
            <div class="card-body">
                <form id="admin-bot" action="<?= adminBaseUrl("ajax/settings/telegram-bot/admin") ?>">
                    <div class="form-group">
                        <label>توکن ربات</label>
                        <input type="text" name="token" value="<?= $adminBotToken ?>" class="form-control" placeholder="توکن ربات را وارد کنید..." required />
                    </div>
                    <div class="form-group">
                        <label>چت آیدی مدیر</label>
                        <input type="text" name="chat_id" value="<?= $adminChatId ?>" class="form-control" placeholder="چت آیدی را وارد کنید..." required />
                    </div>
                    <div class="text-body-tertiary mb-1">
                        <?= inlineIcon("info-circle") ?>
                        برای دریافت چت آیدی از ربات <a target="_blank" href="https://telegram.me/userinfobot?start">userinfobot</a> استفاده کنید.
                    </div>
                    <button type="submit" class="btn btn-primary btn-float-icon mt-3">
                        <?= inlineIcon("save") ?>
                        ذخیره
                    </button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                ربات تلگرام خرید و فروش
            </div>
            <div class="card-body">
                <div class="text-center fw-bold">
                    ربات تلگرام خرید و فروش در دست اقدام است.
                </div>
            </div>
        </div>
    </div>
</div>