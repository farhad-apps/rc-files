<?php
$adminPefixUrl      = getArrayValue($settings, "admin_prefix_url", "");
$fakeUrl            = getArrayValue($settings, "fake_url", "");
$siteTitle          = getArrayValue($settings, "site_title", "");
$footerText         = getArrayValue($settings, "footer_text", "");

?>

<div class="card">
    <div class="card-body">
        <form id="settings-form" method="post" action="<?= adminBaseUrl("ajax/settings/main") ?>">
            <div class="row justify-content-center">
                <div class="col-lg-5">
                    <div class="card border shadow-none">
                        <div class="card-body">
                            <div class="form-group mb-2">
                                <label class="form-label">عنوان سایت</label>
                                <input value="<?= $siteTitle ?>" name="site_title" class="form-control" placeholder="راکت اس اس اچ" />
                            </div>
                            <div class="form-group mb-2">
                                <label class="form-label">پیشوند پنل ادمین</label>
                                <input value="<?= $adminPefixUrl ?>" name="admin_prefix_url" class="form-control text-end dir-ltr" placeholder="rc-admin" />
                            </div>
                            <div class="form-group mb-2">
                                <label class="form-label">آدرس سایت جعلی</label>
                                <input value="<?= $fakeUrl ?>" type="url" name="fake_url" class="form-control text-end dir-ltr" placeholder="https://example.com" />
                            </div>
                            <?php if ($licenseData["plan_name"] == "brillant") { ?>
                                <div class="form-group mb-2">
                                    <label class="form-label">لوگوی سایت (بهترین ابعاد 400x400)</label>
                                    <input type="file" class="form-control" accept=".png,.jpeg,.jpg" name="logo" />
                                </div>
                                <div class="form-group mb-2">
                                    <label class="form-label">فوتر سایت</label>
                                    <textarea class="form-control content" rows="4" placeholder="یک متن جهت فوتر سایت وارد کنید..." name="footer_text"><?= $footerText ?></textarea>
                                </div>
                            <?php } ?>

                            <div class="form-group text-center mt-3 mb-2">
                                <button type="submit" class="btn btn-primary btn-float-icon">
                                    <?= inlineIcon("save") ?>
                                    ذخیره
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </form>
    </div>
</div>