<?php
$receiverEmail  = getArrayValue($autoBackup, "receiver_email", "");
$sendingHours   = getArrayValue($autoBackup, "sending_every_hours", "");
?>
<div class="row">
    <div class="col-md-5">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">بارگذاری فایل پشتیبان</h6>
            </div>
            <div class="card-body">
                <div class="alert alert-info p-2">
                    بعد از وارد کردن فایل پشتیبان نیاز به سینک کاربران روی همه سرورها را دارید.
                </div>
                <form id="import-form" method="post" action="<?= adminBaseUrl("ajax/settings/backup/import") ?>">
                    <div class="form-group mb-2">
                        <label>انتخاب از پنل</label>
                        <select class="form-select" name="import_from" required>
                            <!-- <option value="current">پنل فعلی</option> -->
                            <option value="rokcet_single_server">پنل راکت تک سرور</option>
                        </select>
                    </div>

                    <div class="form-group mb-2">
                        <label>انتخاب مدیر ایجاد کننده</label>
                        <select name="creator" class="form-select">
                            <option value="">انتخاب کنید</option>
                            <?php if ($adminUsers) {
                                foreach ($adminUsers as $user) {
                            ?>
                                    <option value="<?= $user->id ?>"><?= $user->full_name ?> <?= $user->role != "admin" ? " (" . $user->role_name . ")" : "" ?></option>
                            <?php
                                }
                            } ?>
                        </select>
                    </div>

                    <div class="form-group mb-2">
                        <label>انتخاب فایل دیتابیس <span class="unicode-bidi-plain">(*.sql)</span></label>
                        <input type="file" accept=".sql" name="sql_file" class="form-control" required />
                    </div>

                    <div class="text-center">
                        <button type="submit" class="btn btn-primary btn-float-icon">
                            <?= inlineIcon("download") ?>
                            ایمپورت
                        </button>
                    </div>

                </form>
            </div>
        </div>
    </div>
    <div class="col-md-7">
        <div class="card mb-2">
            <div class="card-header">
                <h6 class="mb-0">پشتیبان گیری اتوماتیک</h6>
            </div>
            <div class="card-body">
                <form id="auto-backup-form" method="post" action="<?= adminBaseUrl("ajax/settings/backup/auto") ?>">

                    <div class="text-body-tertiary mb-1">
                        <?= inlineIcon("info-circle") ?>
                        <small>
                            در تنظیمات بخش ربات تلگرام ادمین را فعال کنید ارسال در ربات تلگرام انجام می شود.
                        </small>
                    </div>
                    <div class="form-group">
                        <label>ارسال هر </label>
                        <div class="input-group mb-3">
                            <input type="number" value="<?= $sendingHours ?>" name="sending_every_hours" min="1" max="24" class="form-control" placeholder="یک عدد بین ۱ تا ۲۴ وارد کنید" required />
                            <span class="input-group-text" id="basic-addon1">ساعت یکبار</span>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-float-icon">
                        <?= inlineIcon("save") ?>
                        ذخیره
                    </button>
                </form>
            </div>
        </div>
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">پشتیبان گیری دستی</h6>
            </div>
            <div class="card-body">
                <button id="create-bkp-btn" class="ps-5 btn btn-secondary btn-float-icon">
                    <?= inlineIcon("upload") ?>
                    پیشتبان گیری جدید
                </button>
                <div class="border-bottom my-2"></div>
                <table class="table table-striped" id="backup-table">
                    <thead>
                        <tr>
                            <th>ردیف</th>
                            <th>نام</th>
                            <th>تاریخ ایجاد</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $num = 0;
                        foreach ($backupFiles as $key => $file) {
                            $name = $file["name"];
                            if ($name != "auto-bkp.sql") {
                                $num += 1;
                        ?>
                                <tr class="bkp-row" data-name="<?= $file["name"] ?>">
                                    <td><?= $num ?></td>
                                    <td><?= $file["name"] ?></td>
                                    <td><?= $file["date"] ?></td>
                                    <td>
                                        <button data-name="<?= basename($file["url"]) ?>" class="btn-dl-bkp btn btn-primary">
                                            <?= inlineIcon("download") ?>
                                        </button>
                                        <button class="btn btn-danger btn-delete-bkp" data-name="<?= $file["name"] ?>">
                                            <?= inlineIcon("trash") ?>
                                        </button>
                                    </td>
                                </tr>
                        <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>

            </div>

        </div>
    </div>
</div>