<?php
$userId     = getArrayValue($userValues, "id");
$baseTabUrl = "resellers/$userId/settings?tab=";
?>

<div class="modal-dialog modal-<?= $activeTab == "credits" ? "xl" : "lg" ?> modal-dialog-scrollable">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title">تنظیمات کاربری نماینده</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body p-0">
            <ul class="nav nav-tabs mt-2" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link btn-ajax-views <?= $activeTab == "details" ? "active" : "" ?>" data-url="<?= $baseTabUrl ?>">
                        <?= inlineIcon("file-circle-info") ?>
                        اطلاعات پایه
                    </button>
                </li>
                <li class="nav-item">
                    <button class="nav-link btn-ajax-views <?= $activeTab == "packages" ? "active" : "" ?>" data-url="<?= $baseTabUrl ?>packages">
                        <?= inlineIcon("layer-group") ?>
                        دسترسی پکیج ها
                    </button>
                </li>

                <li class="nav-item">
                    <button class="nav-link btn-ajax-views <?= $activeTab == "credits" ? "active" : "" ?>" data-url="<?= $baseTabUrl ?>credits">
                        <?= inlineIcon("credit-card") ?>
                        تراکنش های مالی
                    </button>
                </li>
            </ul>

            <!-- Tab panes -->
            <div class="tab-content">
                <div class="p-3">
                    <?php require_once "$activeTab.php" ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    var activeTab = "<?= $activeTab ?>";
    var userId = <?= $userId ?>;
    window.initResellerDetails(activeTab, userId);
</script>