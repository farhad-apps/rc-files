<div class="card mb-2">
    <div class="card-header border-0 text-muted">
        <div class=" d-flex align-items-center">
            <?= inlineIcon("users fs-5 me-2") ?>
            <h6 class="mb-0 fw-bold">نمایندگان</h6>
        </div>
    </div>
    <div class="card-body">
        <div class="row g-3">
            <div class="col-6 col-lg-3 mb-2 mb-lg-0">
                <a href="<?= adminBaseUrl("resellers") ?>" class="card">
                    <div class="card-body">
                        <h6 class="widget-title mb-3">کل نمایندگان</h6>
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="fw-bold mb-0 text-primary"><?= $totalData["resellers"]["all"] ?></h5>
                            <span class="widget-icon fs-3 text-primary">
                                <?= inlineIcon("user-group") ?>
                            </span>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-6 col-lg-3 mb-2 mb-lg-0">
                <a href="<?= adminBaseUrl("resellers") ?>" class="card">
                    <div class="card-body">
                        <h6 class="widget-title mb-3">نمایندگان فعال</h6>
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="fw-bold mb-0 text-success"><?= $totalData["resellers"]["active"] ?></h5>
                            <span class="widget-icon fs-3 text-success">
                                <?= inlineIcon("user-group") ?>
                            </span>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-6 col-lg-3 mb-2 mb-lg-0">
                <a href="<?= adminBaseUrl("resellers") ?>" class="card">
                    <div class="card-body">
                        <h6 class="widget-title mb-3">نمایندگان غیر فعال</h6>
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="fw-bold mb-0 text-danger"><?= $totalData["resellers"]["inActive"] ?></h5>
                            <span class="widget-icon fs-3 text-danger">
                                <?= inlineIcon("users-slash") ?>
                            </span>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-6 col-lg-3 mb-2 mb-lg-0">
                <a href="<?= adminBaseUrl("resellers") ?>" class="card">
                    <div class="card-body">
                        <h6 class="widget-title mb-3">اعتبار باقی مانده</h6>
                        <h6 class="fw-bold mb-0 text-danger text-center mb-1">
                            <?= $totalData["resellers"]["totalCredit"] ?> <small>تومان</small>
                        </h6>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>