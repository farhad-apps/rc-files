<?php include "sections/head.php"; ?>
<div class="container h-100">
    <?php include frontViewContents($viewContent); ?>
</div>
<?php include "sections/footer.php"; ?>