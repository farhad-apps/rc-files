<?php include "sections/head.php"; ?>

<?php include frontViewContents($viewContent); ?>

<?php include "sections/footer.php"; ?>