<?php
$userId             = getArrayValue($userInfo, "id");
$username           = getArrayValue($userInfo, "username");
$password           = getArrayValue($userInfo, "password");
$email              = getArrayValue($userInfo, "email");
$mobile             = getArrayValue($userInfo, "mobile");
$traffic            = getArrayValue($userInfo, "ftraffic");
$startDate          = getArrayValue($userInfo, "start_date");
$endDate            = getArrayValue($userInfo, "end_date");
$expiryType         = getArrayValue($userInfo, "expiry_type");
$concurrentUsers    = getArrayValue($userInfo, "limit_users");
$consumerTraffic    = getArrayValue($userInfo, "fconsumer_traffic");
$endDateJD          = getArrayValue($userInfo, "end_time_jd"); //jalali date
$startJD            = getArrayValue($userInfo, "start_time_jd"); //jalali date
$remainingDays      = getArrayValue($userInfo, "remaining_days", 0);
$netmodQrUrl        = getArrayValue($userInfo, "netmod_qr_url", "");
$status             = getArrayValue($userInfo, "status", "");
$creatorName        = getArrayValue($userInfo, "creator_name", "");
$editorName         = getArrayValue($userInfo, "editor_name", "");
$desc               = getArrayValue($userInfo, "desc", "");
$arrayConfig        = getArrayValue($userInfo, "array_config", []);
$diffrenceDate      = getArrayValue($userInfo, "diffrence_date", "");
$publicLink         = getArrayValue($userInfo, "public_link", "");
$utime              = getArrayValue($userInfo, "utime", "");
$ctime              = getArrayValue($userInfo, "ctime", "");


$remainingText  = "$remainingDays";
$isPassDays     = strpos($remainingDays, "گذشته");
if ($isPassDays) {
    $remainingText = "<span class='text-warning'>$remainingDays</span>";
}

$editViewUrl = "subscribers/$userId/edit?ref=details";

$values = [
    [
        "label" => "نام کاربری",
        "value" => $username,
    ],
    [
        "label" => "رمز عبور",
        "value" => "<span class='cursor-pointer' data-copy='true' data-text='$password' data-bs-toggle='tooltip' title='کپی'>$password</span>",
    ],
    [
        "label" =>  "ترافیک",
        "value" => $traffic,
    ],
    [
        "label" => "ترافیک مصرفی",
        "value" => $consumerTraffic ? "<span id='spn-user-traffic'>$consumerTraffic</span>" : 0
    ],
    [
        "label" =>  "تاریخ شروع",
        "value" => $startJD,
    ],
    [
        "label" => "تاریخ پایان",
        "value" => $endDateJD,
    ],
    [
        "label" =>  "مدت زمان",
        "value" => $diffrenceDate,
    ],
    [
        "label" =>  "زمان باقی مانده",
        "value" => $remainingText,
    ],
    [
        "label" =>  "تعداد کاربران",
        "value" => $concurrentUsers,
    ],
];
?>

<div class="row justify-content-center h-100 align-items-center">
    <div class="col-lg-11 ">
        <div class="row g-3">
            <div class="col-lg-5">
                <div class="card shadow-lg border-0">
                    <div class="card-header">
                        اطلاعات پروفایل شما
                    </div>
                    <div class="card-body">
                        <div class="text-center">
                            <img src="<?= siteLogo() ?>" width="80" />
                        </div>
                        <?php if (!empty($settings["welecom_text"])) { ?>
                            <div class="text-center py-2"><?= $settings["welecom_text"] ?></div>
                        <?php } ?>
                        <hr class="my-2" />
                        <div class="row">

                            <?php
                            foreach ($values as  $key => $item) {
                                $label = $item["label"];
                                $value = $item["value"];
                                $class = "d-flex flex-row align-items-center justify-content-between py-1 px-3";
                                if ($key < count($values) - 1) {
                                    $class .= " border-bottom";
                                }
                            ?>
                                <div class="<?= $class ?>">
                                    <span class="text-muted small"><?= $label ?></span>
                                    <span class=" fw-bold"><?= $value ? $value : "-" ?></span>
                                </div>
                            <?php
                            }
                            ?>
                        </div>

                    </div>
                </div>
            </div>

            <div class="col-lg-7">
                <div class="card shadow-lg border-0 h-100">
                    <div class="card-header">
                        اطلاعات کانفیگ های شما
                    </div>
                    <div class="card-body">
                        <div class="row g-1">
                            <?php
                            foreach ($configs  as $protocol => $_configs) {
                            ?>
                                <div class="col-lg-4">
                                    <?= genProtocol($protocol, $_configs) ?>
                                </div>
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php
function genProtocol($protocol, $configs)
{
?>
    <div class="card">
        <div class="card-header">
            پروتکل <?= $protocol ?>
        </div>
        <div class="card-body p-1 scroll-bar" style="height: 320px;overflow-y:auto">
            <?php
            if ($protocol == "openvpn") {
                foreach ($configs as $config) {
                    $serverName = $config["server_name"];
                    $serverId   = $config["server_id"];
                    $serverFlag = $config["server_flag"];
            ?>
                    <div class="mb-2 pb-2 d-flex align-items-center justify-content-between border-bottom">
                        <div>
                            <img class="rounded-circle" src="<?= $serverFlag ?>" width="25" height="25" />
                            <small> سرور <?= $serverName ?></small>
                        </div>
                        <a href="<?= baseUrl("ovpn-config/$serverId") ?>" class="btn btn-sm btn-warning btn-icon" target="_blank" download="">
                            <?= inlineIcon("download") ?>
                        </a>
                    </div>
                    <?php
                }
            } else {
                foreach ($configs as $domain => $aconfigs) {

                    foreach ($aconfigs as $p => $values) {
                        $url = $values;
                        if ($protocol == "ssh") {
                            $url = $values["qrcode"];
                        }
                        $urlParams = parseUrl($url);
                        $text      = getArrayValue($urlParams, "text");
                    ?>
                        <div class="mb-2 text-center">
                            <?php if ($protocol == "v2ray") {  ?>
                                <button class="btn btn-info btn-sm v2-copy-config" data-protocol="<?= $protocol ?>" data-text="<?= $text ?>">
                                    <?= inlineIcon("copy") ?>
                                    کپی کانفیگ <?= $p ?>
                                </button>
                            <?php } else { ?>
                                <button class="btn btn-info btn-sm ssh-copy-config" data-config="<?= base64_encode(json_encode($values)) ?>">
                                    <?= inlineIcon("copy") ?>
                                    کپی کانفیگ
                                </button>
                            <?php } ?>
                            <img class="cursor-pointer img-fluid" src="<?= $url ?>" />
                            <?php if (count($configs) > 1) { ?>
                                <hr class="my-2" />
                            <?php } ?>
                        </div>
            <?php
                    }
                }
            }
            ?>
        </div>
    </div>
<?php
}
?>
<script>
    var arrayConfig = <?= json_encode($arrayConfig) ?>;
</script>