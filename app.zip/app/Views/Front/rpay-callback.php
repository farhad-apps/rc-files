<?php
$status         = $response["status"];
$transId        = $response["trans_id"];
$paymentData    = getArrayValue($response, "payment_data");
?>
<div class="container h-100">
    <div class="row justify-content-center h-100 align-items-center">
        <div class="col-lg-5">
            <div class="card text-center">
                <div class="card-header">
                    نتیجه پرداخت
                </div>
                <div class="card-body">
                    <div class="mb-3">شماره تراکنش:<?= $transId ?></div>
                    <?php
                    if ($status == "success") {
                    ?>
                        <h4 class="text-success">پرداخت با موفقیت انجام شد</h4>

                    <?php
                    } else {
                    ?>
                        <h4 class="text-danger">پرداخت با خطا انجام شد</h4>
                    <?php
                    }
                    ?>
                    <br />
                    <a class="btn btn-primary" href="<?= adminBaseUrl("settings/license") ?>">
                        <?= inlineIcon("arrow-right") ?>
                        بازگشت
                    </a>
                </div>
                <div class="card-footer">
                    <div class="small text-gray">
                        در صورت پرداخت و عدم تایید آن با پشتیبانی در تلگرام تماس بگیرد و کد تراکنش را نزد خود نگه دارید.
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>