<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use Morilog\Jalali\Jalalian;

class Domains extends \App\Models\BaseModel
{

    protected $table        = 'domains';
    protected $primaryKey   = 'id';
    protected $fillable = [
        'name',
        'subdomain',
        'zone_id',
        'category_id',
        'ctime',
    ];


    public function getInfo($id)
    {
        $query = db($this->table)->where("id", $id)
            ->get();
        if ($query->count()) {
            $row = $query->first();
            return  $row;
        }
        return false;
    }

    public function checkExist($id)
    {
        return $this->where("id", $id)->count();
    }

    public function saveDomains($pdata, $editId = null)
    {
        $columnsArr                 = [];
        $pdata                      = trimArrayValues($pdata);

        $categoryId                 = getArrayValue($pdata, "category", 0);
        $columnsArr["subdomain"]    = $pdata["subdomain"];
        $columnsArr["zone_id"]      = $pdata["zone_id"];
        $columnsArr["category_id"]  = getArrayValue($pdata, "category", 0);
        $columnsArr["ctime"]        = time();

        $where = ["subdomain" => $pdata["subdomain"], "category_id" => $categoryId];
        $this->updateOrCreate($where, $columnsArr);
    }

    public function deleteDomain($id, $uid)
    {
        $this->where("id", $id)->delete();
    }

    public function getAllDomains($category = 0)
    {
        $query = db($this->table);
        if ($category) {
            $query->where("category_id", $category);
        }
        $query =  $query->get();
        if ($query->count()) {
            $rows = $query->toArray();
            return  $rows;
        }

        return false;
    }

    public function dataTableList($pdata, $uid)
    {
        $select = ["domains.*", "categories.name as category"];

        $query = $this->select($select)
            ->leftJoin("categories", "categories.id", "=", "domains.category_id");

        $DataTable      = new \App\Libraries\DataTable($query, $pdata);
        $domains        = $DataTable->query()->toArray();

        $resDomains     = array();
        $num            = (!empty($pdata['start'])) ? $pdata['start'] : 0;

        foreach ($domains as $domain) {
            $num = $num + 1;
            $row = array();

            $createTime = Jalalian::forge($domain["ctime"]);
            $row['id']                  = $domain["id"];
            $row['idx']                 = $num;
            $row['subdomain']           = $domain["subdomain"];
            $row['category']            = $domain["category"];
            $row['zone_id']             = $domain["zone_id"];
            $row['ctime']               = $createTime->format("Y/m/d");
            $resDomains[] = $row;
        }

        $result = $DataTable->make($resDomains);
        return $result;
    }

    public function getRandomDomain()
    {
        $query = db($this->table)
            ->select("subdomain")
            ->where("category_id", 0)
            ->orderByRaw("RAND()")
            ->limit(1)
            ->get();
        if ($query->count()) {
            $row = $query->first();
            return $row->subdomain;
        }
        return "";
    }

    public function groupDomainsByCat()
    {
        $prefix = getConfig("db")["prefix"];
        $tbl    = $prefix . "domains";

        $query = db($this->table)
            ->select("categories.name")
            ->selectRaw("GROUP_CONCAT($tbl.subdomain) as domains")
            ->leftJoin("categories", "categories.id", "=", "domains.category_id")
            ->groupBy("domains.category_id")
            ->get();
        if ($query->count()) {
            $rows   = $query->toArray();
            $result = [];
            foreach ($rows as $row) {
                $name = $row->name;
                $name = $name ? $name : "بدون دسته بندی";
                $result[$name] = explode(",", $row->domains);
            }
            return $result;
        }
        return false;
    }

    public function getSubdomainByCategory($catId)
    {
        $prefix = getConfig("db")["prefix"];

        $query = db($this->table)
            ->select("domains.subdomain")
            ->where("domains.category_id", $catId)
            ->get();
        if ($query->count()) {
            $row   = $query->first();
            return $row->subdomain;
        }
        return false;
    }

    public function getAllProtocloDomain()
    {
        $query = db($this->table)
            ->select("domains.subdomain","domains.id as domain_id", "categories.protocol", "categories.id")
            ->join("categories", "categories.id", "=", "domains.category_id")
            ->get();
        if ($query->count()) {
            $rows   = $query->toArray();
            $result = [];
            foreach ($rows as $row) {
                $result[$row->protocol][] = [
                    "domain"    => $row->subdomain,
                    "category"  => $row->id,
                    "id"        => $row->domain_id,
                ];
            }
            return $result;
        }
        return false;
    }
}
