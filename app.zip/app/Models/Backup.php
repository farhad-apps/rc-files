<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use Morilog\Jalali\Jalalian;


class Backup extends \App\Models\BaseModel
{

    public function __construct()
    {
        ini_set('memory_limit', '256M');
        ini_set('max_execution_time', '0');
    }

    public function getUserBackups()
    {
        $backupPath = PATH_ASSETS . DS . "backup";
        $sqlFiles = array();

        $folderName = str_replace(PATH, "", $backupPath);


        $files = glob($backupPath . '/*.sql');
        foreach ($files as $file) {
            $fileTime   = filectime($file);
            $jdate      = Jalalian::forge($fileTime)->format('Y/m/d - H:i');
            $filename   =  basename($file);
            $sqlFiles[$fileTime] = [
                "name"  =>  $filename,
                "url"   =>  baseUrl("$folderName/$filename"),
                "date"  =>  $jdate,
            ];
        }
        arsort($sqlFiles);

        return array_values($sqlFiles);
    }
    

    public function importOldRocket($values, $uid)
    {

        if (!empty($values["cp_users"]) && !empty($values["cp_traffics"])) {

            $subsModel      = new \App\Models\Subscribers();
            $totalSubs      = $subsModel->getTotalActiveSubs();

            $cpUsers        = $values["cp_users"];
            $cpTraffics     = $values["cp_traffics"];
            $totalInsert    = 0;


            $usersColumns   = [];
            $subsColumns    = [];

            $usersTraffics = [];
            foreach ($cpTraffics as $cpTraffic) {
                $usersTraffics[$cpTraffic["username"]] = $cpTraffic;
            }

       
            foreach ($cpUsers as $cpUser) {
                $status     = $cpUser["status"];
                $username   = $cpUser["username"];
                $statusDesc = "";

                if ($status == "de_active" || $status == "expiry_date" || $status == "expiry_traffic") {
                    $status = "inactive";
                    if ($status == "expiry_date") {
                        $statusDesc  = "time_expiration";
                    }
                    if ($status == "expiry_traffic") {
                        $statusDesc  = "traffic_expiration";
                    }
                }

                $traffiColumns = [];
                if (isset($usersTraffics[$username])) {
                    $uTraffic       = $usersTraffics[$username];
                    unset($uTraffic["username"]);
                    unset($uTraffic["id"]);
                    $traffiColumns  = $uTraffic;
                }
                if (empty($traffiColumns)) {
                    $traffiColumns['user_id']   = 0;
                    $traffiColumns['download']  = 0;
                    $traffiColumns['upload']    = 0;
                    $traffiColumns['total']     = 0;
                    $traffiColumns['ctime']     = time();
                    $traffiColumns['utime']     = 0;
                }

                $subsColumns = [
                    "package_id"    => 0,
                    "start_time"    => $cpUser["start_date"],
                    "end_time"      => $cpUser["end_date"],
                    "token"         => $cpUser["token"],
                    "limit_users"   => $cpUser["limit_users"],
                    "traffic"       => $cpUser["traffic"],
                    "validity_days" => $cpUser["expiry_days"],
                    "price"         => 0,
                    "category_id"   => 0,
                    "uuid"          => "",
                ];

                $usersColumns[] = [
                    "username"      => $cpUser["username"],
                    "password"      => $cpUser["password"],
                    "mobile"        => $cpUser["mobile"],
                    "status"        => $status,
                    "status_desc"   => $statusDesc,
                    "role"          => "subscriber",
                    "desc"          => $cpUser["desc"],
                    "ctime"         => $cpUser["ctime"],
                    "utime"         => $cpUser["utime"],
                    "cid"           => $uid,
                    "uid"           => 0,
                    "credit"        => 0,
                    "unlimited"     => 0,
                    "full_name"     => "",
                    "subs_cols"     => $subsColumns,
                    "traffic_cols"  => $traffiColumns,
                ];
            }

            $totalLimit = getTotalRowsInPlan("subscribers");
            $totalLimit = $totalLimit ? $totalLimit : 100000;

            if ($totalSubs < $totalLimit) {

                foreach ($usersColumns as $key => $user) {
                    $passKey = true;
                    if ($totalLimit &&  $key >= $totalLimit) {
                        $passKey = false;
                    }
                    if ($passKey) {
                        $username   = $user["username"];
                        $checkExist = db("users")->where("username", $username)->count();

                        if (!$checkExist) {

                            try {
                                db()::transaction(function () use ($user) {
                                    $subsCols      = $user["subs_cols"];
                                    $trafficCols   = $user["traffic_cols"];

                                    unset($user["subs_cols"]);
                                    unset($user["traffic_cols"]);
                                    $userId =  db("users")->insertGetId($user);

                                    $subsCols["user_id"]    = $userId;
                                    $trafficCols["user_id"] = $userId;

                                    db("users_subs")->insert($subsCols);
                                    db("users_traffics")->insert($trafficCols);
                                });
                                $totalInsert++;
                            } catch (\Exception $err) {
                                db()::rollback();
                                throw $err;
                            }
                        }
                    }
                }
            }

            return $totalInsert;
        }
    }
}
