<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use \App\Libraries\Mysqldump as IMysqldump;

class Cronjob extends \App\Models\BaseModel
{

    public function init()
    {
        $schedules  = [];
        $sModel     = new \App\Models\Settings();
        $settings   = $sModel->getSettings();

        $autoBackup             = getArrayValue($settings, "auto_backup", false);
        $filteringHours         = getArrayValue($settings, "servers_check_filtering_hours", false);
        $onlineLimit            = getArrayValue($settings, "servers_online_limit", "");

        $checkFiltering         = getArrayValue($settings, "servers_check_filtering", []);
        $filteringEnabled       = getArrayValue($checkFiltering, "enabled", "");
        $filteringHours         = getArrayValue($checkFiltering, "hours", "");


        $checkAvailability      = getArrayValue($settings, "servers_check_availability", []);
        $availabilityEnabled    = getArrayValue($checkAvailability, "enabled", "");
        $availabilityHours      = getArrayValue($checkAvailability, "hours", "");

        if (!empty($autoBackup)) {
            $schedules["autoBackup"]            = $autoBackup["sending_every_hours"] * 3600;
        }

        if (!empty($onlineLimit)) {
            $schedules["serversOnlineLimit"]    = 0;
        }

        if (!empty($availabilityEnabled)) {
            $schedules["serversAvailability"]   = $availabilityHours * 3600;
        }

        if ($filteringEnabled) {
            $schedules["checkhostReqId"]        = 2 * 60;
            $schedules["getCheckhostReqId"]     = $filteringHours * 3600;
        }

        $schedules["expiredUsers"]              = 10 * 60;
        $schedules["autoUsersLogout"]           = 0;
        $schedules["removOldConnLogs"]          = 0;
        $schedules["checkLicense"]              = 6 * 3600;
        $schedules["appLastVersion"]            = 5 * 600;
        $schedules["createUserBanner"]          = 15 * 60;

        $lastExecutionFile =  PATH_STORAGE . DS . "cron.json";

        foreach ($schedules as $key => $interval) {

            $lastExecutionTime = 0;
            if (file_exists($lastExecutionFile)) {
                $fileContent        = file_get_contents($lastExecutionFile);
                if (!empty($fileContent)) {
                    $data               = json_decode($fileContent, true);
                    $lastExecutionTime  = $data[$key] ?? 0;
                }
            }

            $currentTime = time();

            // Check if it's time to execute based on the interval
            if ($currentTime - $lastExecutionTime >= $interval) {
                $data[$key] = $currentTime;
                //save
                @file_put_contents($lastExecutionFile, json_encode($data));

                $this->$key($settings);
            }
        }
    }

    public function expiredUsers()
    {
        $uModel         = new \App\Models\Subscribers();
        $activeUsers    = $uModel->getActiveUsers();

        if ($activeUsers) {

            $deactiveUsers  = [];
            foreach ($activeUsers as $user) {
                $userId         = $user->user_id;
                $uuid           = $user->uuid;
                $username       = $user->username;
                $totalTraffic   = $user->traffic;
                $cTraffic       = $user->consumer_traffic;
                $validityDays   = $user->validity_days;
                $cTraffic       = $cTraffic ? $cTraffic : 0;

                $endTime        = $user->end_time;
                $startTime      = $user->start_time;

                if ($startTime) {
                    $isReset        = false;
                    $resetStatus    = "";

                    if ($validityDays > 0) {
                        if (time() > $endTime) {
                            $isReset = true;
                            $resetStatus = "time_expiration";
                        }
                    }

                    if (!$isReset) {
                        if ($totalTraffic && ($cTraffic > $totalTraffic)) {
                            $isReset = true;
                            $resetStatus = "traffic_expiration";
                        }
                    }

                    if ($isReset) {
                        $deactiveUsers[] = ["username" => $username, "uuid" => $uuid];
                        $uModel->updateStatus($userId, "inactive", 0, $resetStatus);
                    }
                }
            }


            if (!empty($deactiveUsers)) {
                $sModel = new \App\Models\Servers();
                $sModel->actionUsersInServers("deactivate", $deactiveUsers);
            }
        }
    }

    public function removOldConnLogs($settings)
    {
        $servDelSubsLogMin  = getArrayValue($settings, "servers_delete_subs_logs_minute", false);


        $time = time() - ($servDelSubsLogMin * 60);

        db("conn_logs")
            ->where("login_time", ">", 0)
            ->where(function ($q) use ($time) {
                $q->where("logout_time", ">", 0)
                    ->where("logout_time", "<=", $time);
            })
            ->delete();

        $time = time() - (2 * 86400);
        db("conn_logs")
            ->where("login_time", "<", $time)
            ->where("logout_time", "=", 0)
            ->where("pid", "=", "")
            ->delete();
    }

    public function autoUsersLogout()
    {
        $lastTime = time() - 20;

        $select = [
            "conn_logs.id as log_id",
            "users_online.*"
        ];

        $query = db("conn_logs")->select($select)
            ->join("users_online", "users_online.user_id", "=", "conn_logs.user_id")
            ->where("conn_logs.logout_time", 0)
            // ->whereIn("users_online.vpn_protocol", ["ssh", "v2ray"])
            ->where("users_online.last_activity", "<=", $lastTime)
            ->get();

        if ($query->count()) {
            $rows = $query->toArray();

            $serversId = [];
            foreach ($rows as $row) {
                $serversId[$row->server_id][] = $row;
            }

            $sModel     = new \App\Models\Servers();
            $conModel   = new \App\Models\ConnLogs();
            $uoModel    = new \App\Models\UsersOnline();

            foreach ($serversId  as $serverId => $users) {
                $serverInfo = $sModel->getInfo($serverId);

                if ($serverInfo) {
                    $ip        = $serverInfo->ip;
                    $serverApi = new  \App\Libraries\ServerApi($ip);

                    foreach ($users as $user) {
                        $pid        = $user->pid;
                        $userIp     = $user->user_ip;
                        $protocol   = $user->vpn_protocol;
                        try {
                            $serverApi->killUserByPid($protocol, $userIp, $pid);
                        } catch (\Exception $err) {
                        }
                    }
                }

                foreach ($users as $user) {
                    $logId      = $user->log_id;
                    $userId     = $user->user_id;
                    $sessionKey = $user->session_key;

                    $conModel->addLogoutTimeById($logId);
                    $uoModel->removeOnlineUser($userId, $serverId, $sessionKey);
                }
            }
        }
    }

    public function checkLicense()
    {
        $setModel       = new \App\Models\Settings();
        $licenseData    = $setModel->getLicenseData();

        if (!empty($licenseData)) {

            $plan       = $licenseData["plan_name"];
            $checker    = new \App\Libraries\RocketApi();

            if ($plan != "free") {
                $result   = $checker->getLicenseDetails();
                if (!$result) {
                    $setModel->getLicenseData(true);
                } else {
                    $setModel->saveLicenseData($result);
                }
            }
        }
    }

    public function createUserBanner($settings)
    {
        $subsModel  = new \App\Models\Subscribers();
        $serveModel = new \App\Models\Servers();
        $settModel  = new \App\Models\Settings();
        $users      = $subsModel->getActiveUsers();
        $servers    = $serveModel->getAllActive();

        if ($users && $servers) {
            $serverNet      = new  \App\Libraries\ServerNet();

            $serversSSH     = getArrayValue($settings, "servers_ssh", []);
            $sshPort        = getArrayValue($serversSSH, "port", "");
            $sshBanner      = getArrayValue($serversSSH, "banner", "");

            $removeBanner   = getArrayValue($settings, "last_remove_users_banner");

            if ($sshBanner) {

                $sshdContent = "ClientAliveInterval 30\n";
                $sshdContent .= "ClientAliveCountMax 1\n";
                $sshdContent .= "Port $sshPort\n\n";

                $customBanner = getArrayValue($settings, "banner_text");

                $bannerPath = PATH_APP . DS . "Views" . DS . "user-banner.php";

                foreach ($users as $key => $user) {
                    $userDetails = $subsModel->getByUsername($user->username);
                    $username   = $user->username;

                    $vars   = ["userInfo" => $userDetails, "customBanner" => $customBanner];
                    $html   = includeWithVariables($bannerPath, $vars, false);
                    $user->banner = $html;

                    $userBanner    = "Match User $username\nBanner /var/ssh-banners/$username";
                    $sshdContent .= "\n" . $userBanner . "\n";

                    $users[$key] = $user;
                }

                foreach ($servers as $serverInfo) {

                    $ip        = $serverInfo->ip;
                    $sshUser   = $serverInfo->ssh_user;
                    $sshPass   = $serverInfo->ssh_pass;
                    $sshPort   = $serverInfo->ssh_port;

                    try {
                        $serverNet->setConfig($ip, $sshUser, $sshPass, $sshPort);
                        $serverNet->login();
                        $serverNet->runCommand("mkdir /var/ssh-banners");
                        foreach ($users as $user) {
                            $username   = $user->username;
                            $banner     = $user->banner;
                            $serverNet->createUserBannerFile($username, $banner);
                        }
                        $serverNet->fillRocketSshdContent($sshdContent);
                        $serverNet->restartSSH();
                        $serverNet->disconnect();
                    } catch (\Exception $err) {
                    }
                }
            } else {
                if (!$removeBanner) {
                    $sshdContent = "ClientAliveInterval 30\n";
                    $sshdContent .= "ClientAliveCountMax 1\n";
                    $sshdContent .= "Port $sshPort\n\n";

                    foreach ($servers as $serverInfo) {

                        $ip        = $serverInfo->ip;
                        $sshUser   = $serverInfo->ssh_user;
                        $sshPass   = $serverInfo->ssh_pass;
                        $sshPort   = $serverInfo->ssh_port;

                        try {
                            $serverNet->setConfig($ip, $sshUser, $sshPass, $sshPort);
                            $serverNet->login();

                            $serverNet->fillRocketSshdContent($sshdContent);
                            $serverNet->restartSSH();
                            $serverNet->disconnect();
                        } catch (\Exception $err) {
                        }
                    }

                    $settModel->setSettings("last_remove_users_banner", 1);
                }
            }
        }
    }

    public function appLastVersion()
    {
        $lastVersion = githubLastVersion();

        if ($lastVersion) {
            $where  = ["name" => "app_last_version"];
            $values = ["name" => "app_last_version", "value" => $lastVersion];
            \App\Models\Settings::updateOrCreate($where, $values);
        }
    }

    public function autoBackup($settings)
    {
        $autoBackup    = getArrayValue($settings, "auto_backup");
        $botSett       = getArrayValue($settings, "admin_telegram_bot");

        if (!empty($autoBackup) && !empty($botSett)) {
            $botToken       = $botSett["token"];
            $botChatId      = $botSett["chat_id"];

            $dbConf         = getConfig("db");
            $domain         = parse_url(baseUrl(), PHP_URL_HOST);

            $filename       = str_replace(".", "-", $domain);
            $backupPath     = PATH_ASSETS . DS . "backup";
            $backupFilePath = $backupPath . DS . "$filename.sql";

            $conf = "mysql:host=" . $dbConf["host"] . ";dbname=" . $dbConf["database"];
            $dump = new IMysqldump($conf, $dbConf["username"], $dbConf["password"]);
            $dump->start($backupFilePath);


            $telegram   = new \App\Libraries\Telegram($botToken);
            $document   = new \CURLFile($backupFilePath);

            $caption    = "بکاپ اتوماتیک دیتابیس" . "\n";
            $caption    .= "دامنه: $domain" . "\n";
            $caption    .= "تاریخ: " . jdate()->format("Y-m-d H:i");

            $res = $telegram->sendDocument([
                "chat_id"   => $botChatId,
                "document"  => $document,
                "caption"   => $caption,
            ]);
         


            @unlink($backupFilePath);
        }
    }

    public function getCheckhostReqId($settings)
    {
        $servModel  = new \App\Models\Servers();
        $serverInfo = $servModel->getFirstForCheckFiltering();
        if ($serverInfo) {
            $serversSSH     = getArrayValue($settings, "servers_ssh", []);
            $sshPort        = getArrayValue($serversSSH, "port", "");

            $serverId   = $serverInfo->id;
            $serverIp   = $serverInfo->ip;
            $serverHost = "$serverIp:$sshPort";

            $chkHost    = new \App\Libraries\CheckHostApi($serverHost);
            $requestId  = $chkHost->getRequestId();
            if (!empty($requestId)) {
                $servModel->setMeta($serverId, "checkhost_reqid", $requestId);
            }
            sleep(2);
            $this->getCheckhostReqId($settings);
        }
    }

    public function checkhostReqId($settings)
    {
        $servModel  = new \App\Models\Servers();
        $result     = $servModel->getFirstCheckhostId();
        $botSett    = getArrayValue($settings, "admin_telegram_bot");
        $banSms     = getArrayValue($settings, "servers_ban_sms");

        if (!empty($result) && !empty($botSett) && !empty($banSms)) {
            $enabled        = isset($banSms["enabled"]) ? $banSms["enabled"] : false;
            if ($enabled) {
                $metaId         = $result->id;
                $requestId      = $result->meta_value;
                $serverIp       = $result->ip;
                $serverName     = $result->name;
                $msgText        = $banSms["text"];
                $botToken       = $botSett["token"];
                $botChatId      = $botSett["chat_id"];

                $message        = str_replace("[server-ip]", $serverIp, $msgText);
                $message        = str_replace("[server-name]", $serverName, $message);

                $chkHost        = new \App\Libraries\CheckHostApi();
                $chkHost->setRequestId($requestId);
                $response = $chkHost->checkResult($requestId);

                if (!empty($response)) {
                    $result = $chkHost->parseResponse($response, ["ir"]);

                    if (!empty($result)) {
                        $totalOff   = 0;
                        foreach ($result as $values) {
                            if ($values["status"] == "filter") {
                                $totalOff += 1;
                            }
                        }
                        if ($totalOff >= 2) {
                            $telegram      = new \App\Libraries\Telegram($botToken);
                            $telegram->sendMessage(["chat_id" => $botChatId, "text" => $message]);
                        }
                    }
                }
                $servModel->deleteMeta($metaId);
            }
        }
    }

    public function serversOnlineLimit()
    {
        $servModel = new \App\Models\Servers();
        $servers = $servModel->getAllActive();

        if ($servers) {

            foreach ($servers as $server) {
                $serverId       = $server->id;
                $serverIp       = $server->ip;
                $totalOnline    = $server->total_online;
                $limitOnline    = $server->limit_online_users;
                if ($limitOnline > 0) {

                    if ($totalOnline > $limitOnline) {

                        $lastTime   = time() - 300;

                        $query      = db("users_online")
                            ->select("username", "session_key", "pid", "user_ip", "vpn_protocol")
                            ->join("users", "users.id", "=", "users_online.user_id")
                            ->where("users_online.ctime", "<", $lastTime)
                            ->where("users_online.server_id", $serverId)
                            ->orderBy("users_online.ctime", "ASC");

                        $cquety = clone $query;
                        $limit  = $totalOnline  - $cquety->count();

                        $query->limit($limit);
                        $query = $query->get();

                        if ($query->count()) {
                            $users      = $query->toArray();
                            $serverApi  = new  \App\Libraries\ServerApi($serverIp);

                            foreach ($users as $user) {
                                try {
                                    $pid        = $user->pid;
                                    $userIp     = $user->user_ip;
                                    $protocol   = $user->vpn_protocol;
                                    $serverApi->killUserByPid($protocol, $userIp, $pid);
                                } catch (\Exception $err) {
                                }
                            }
                        }
                    }
                }
            }
        }
    }


    public function serversAvailability($settings, $nextId  = 0)
    {

        $servModel  = new \App\Models\Servers();
        $server     = $servModel->getFirstForCheckAvail($nextId);

        if ($server) {
            $serverIp   = $server->ip;
            $serverId   = $server->id;
            $serverName = $server->name;

            $serverApi  = new \App\Libraries\ServerApi($serverIp);
            try {
                $serverApi->getResources();
            } catch (\Exception $err) {
                $message    = getArrayValue($settings, "servers_check_availability_msg", "");
                $botSett    = getArrayValue($settings, "admin_telegram_bot");
                if ($message && !empty($botSett)) {
                    $message        = str_replace("[server-ip]", $serverIp, $message);
                    $message        = str_replace("[server-name]", $serverName, $message);
                    $botToken       = $botSett["token"];
                    $botChatId      = $botSett["chat_id"];

                    $telegram       = new \App\Libraries\Telegram($botToken);
                    $telegram->sendMessage(["chat_id" => $botChatId, "text" => $message]);
                }
            }
            $this->serversAvailability($settings, $serverId);
        }
    }
}
