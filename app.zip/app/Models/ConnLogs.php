<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use Morilog\Jalali\Jalalian;

class ConnLogs extends \App\Models\BaseModel
{
    protected $table        = 'conn_logs';
    protected $primaryKey   = 'id';

    protected $fillable = [
        'user_id',
        'server_id',
        'login_time',
        'logout_time',
        'pid',
    ];


    public function addLoginTime($userId, $serverId, $pid, $vpnProtocol = "ssh")
    {
        $this->insert([
            'user_id'       => $userId,
            'server_id'     => $serverId,
            'pid'           => $pid,
            'login_time'    => time(),
            "vpn_protocol"  => $vpnProtocol,
            'logout_time'   => 0,
        ]);
    }

    public function addLogoutTime($userId, $serverId, $pid)
    {
        $whereArr = [
            'user_id'       => $userId,
            'server_id'     => $serverId,
            'logout_time'   => 0,
            'pid'           => $pid
        ];

        $this->where($whereArr)->update([
            'logout_time'   => time(),
        ]);
    }

    public function addLogoutTimeById($logId)
    {

        $this->where("id", $logId)->update([
            'logout_time'   => time(),
        ]);
    }


    public function dataTableList($pdata, $uid, $userRole)
    {
        $select = [
            "conn_logs.*",
            "users.username",
            "servers.ip as server_ip",
            "servers.name as server_name",
        ];

        $query = db($this->table)->select($select)
            ->join('users', 'users.id', '=', 'conn_logs.user_id')
            ->join('servers', 'servers.id', '=', 'conn_logs.server_id')
            ->orderBy("conn_logs.id", "DESC");

        if ($userRole != "admin") {
            $query->where("users.cid", $uid);
        }

        if (!empty($pdata["search"]["value"])) {
            $search = $pdata["search"]["value"];
            $search = trim($search);

            if (!empty($search)) {
                $query->where(function ($q) use ($search) {
                    $q->where("users.username",     "LIKE", "%$search%")
                        ->orWhere("users.mobile",   $search)
                        ->orWhere("servers.ip",   $search)
                        ->orWhere("servers.name",   "LIKE",  "%$search%")
                        ->orWhere("users.desc",     "LIKE",  "%$search%");
                });
            }
            $pdata["search"]["value"] = "";
        }

        $DataTable      = new \App\Libraries\DataTable($query, $pdata);
        $users          = $DataTable->query()->toArray();

        $resUsers   = array();
        $num        = (!empty($pdata['start'])) ? $pdata['start'] : 0;

        $duTime     = new \App\Libraries\DurationTime();
        foreach ($users as $user) {
            $user       = (array) $user;
            $num        = $num + 1;
            $row        = array();

            $logoutTime = $user["logout_time"];
            $loginTime  = $user["login_time"];
            $duration   = 0;
            $ctime      = time();
            if ($logoutTime) {
                $ctime  = $logoutTime;
            }
            $duration       = $ctime - $loginTime;
            $durationFormat = $duTime->humanize($duration);
            $vpnProtocol    = $user["vpn_protocol"];

            $row['id']                      = $user["id"];
            $row['idx']                     = $num;
            $row['username']                = $user["username"];
            $row['server_name']             = $user["server_name"];
            $row['server_ip']               = $user["server_ip"];
            $row['protocol_img']            = assets("images/protocol/$vpnProtocol.png");
            $row['vpn_protocol']            = $vpnProtocol;
            $row['duration']                = $duration;
            $row['duration_format']         = $durationFormat;
            $row['login_time']              = Jalalian::forge($loginTime)->format('Y/m/d - H:i');
            $row['logout_time']             = $logoutTime ? Jalalian::forge($logoutTime)->format('Y/m/d - H:i') : 0;

            $resUsers[] = $row;
        }
        $result = $DataTable->make($resUsers);
        return $result;
    }

    public function getUserLastConnLog($userId)
    {

        $lastInfo = $this->where("user_id", $userId)
            ->orderBy("id", "DESC")
            ->limit(1)
            ->first();
        if (!empty($lastInfo)) {
            return $lastInfo;
        }

        return false;
    }


    public function deleteAll()
    {
        $prefix     = getConfig("db")["prefix"];
        $table      = $prefix . "conn_logs";
        db()::statement("TRUNCATE TABLE $table");
    }
}
