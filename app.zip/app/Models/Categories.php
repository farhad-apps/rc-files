<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use Morilog\Jalali\Jalalian;

class Categories extends \App\Models\BaseModel
{

    protected $table        = 'categories';
    protected $primaryKey   = 'id';
    protected $fillable = [
        'name',
        'cid',
        'ctime',
        'protocol',
    ];
    public function getInfo($id)
    {
        $query = db($this->table)->where("id", $id)
            ->get();
        if ($query->count()) {
            $row = $query->first();
            return  $row;
        }
        return false;
    }

    public function checkExist($id)
    {
        return $this->where("id", $id)->count();
    }

    public function saveCategory($pdata, $editId = null, $uid)
    {
        $columnsArr     = [];
        $pdata          = trimArrayValues($pdata);

        $columnsArr["name"]         = $pdata["name"];
        $columnsArr["protocol"]     = $pdata["protocol"];

        if (!$editId) {
            $where = ["name" => $pdata["name"]];

            $columnsArr["cid"]      = $uid;
            $columnsArr["ctime"]    = time();
        } else {
            $where = ["id" => $editId];
        }

        $this->updateOrCreate($where, $columnsArr);
    }

    public function deleteCategory($id, $uid)
    {
        $this->where("id", $id)->delete();
    }

    public function getAll()
    {
        $query = db($this->table)->get();
        if ($query->count()) {
            $rows = $query->toArray();
            return  $rows;
        }

        return false;
    }

    public function dataTableList($pdata, $uid)
    {
        $select = ["*"];

        $query          = $this->select($select);
        $DataTable      = new \App\Libraries\DataTable($query, $pdata);
        $categories     = $DataTable->query()->toArray();

        $resCats        = array();
        $num            = (!empty($pdata['start'])) ? $pdata['start'] : 0;

        foreach ($categories as $category) {
            $num = $num + 1;
            $row = array();

            $createTime = Jalalian::forge($category["ctime"]);

            $row['id']          = $category["id"];
            $row['idx']         = $num;
            $row['name']        = $category["name"];
            $row['protocol']    = $category["protocol"];
            $row['ctime']       = $createTime->format("Y/m/d");
            $resCats[]   = $row;
        }

        $result = $DataTable->make($resCats);
        return $result;
    }


}
