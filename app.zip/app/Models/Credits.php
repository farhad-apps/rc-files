<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use Morilog\Jalali\Jalalian;


class Credits extends \App\Models\BaseModel
{

    protected $table        = 'credits';
    protected $primaryKey   = 'id';
    protected $fillable = [
        'user_id',
        'operation',
        'amount',
        'description',
        'cid',
        'ctime'
    ];


    //addCredit
    public function addCredit($pdata, $userId, $uid)
    {

        $columnsArr     = [];
        $pdata          = trimArrayValues($pdata);

        $operation      = $pdata["operation"];
        $amount         = removeCommaStr($pdata["amount"]);

        $columnsArr["user_id"]      = $userId;
        $columnsArr["operation"]    = $operation;
        $columnsArr["amount"]       = $amount;
        $columnsArr["desc"]         = $pdata["desc"];
        $columnsArr["cid"]          = $uid;
        $columnsArr["ctime"]        = time();

        $this->insert($columnsArr);

        if ($operation == "inc") {
            db("users")->where("id", $userId)->increment('credit', $amount);
        } else {
            db("users")->where("id", $userId)->decrement('credit', $amount);
        }
    }


    public function dataTableList($pdata, $userRole, $uid)
    {
        $select = [
            "credits.*",
            "users.full_name as user_name",
            "creator.full_name as creator_name"
        ];

        $query = $this->select($select)
            ->leftJoin("users", "users.id", "=", "credits.user_id")
            ->join("users as creator", "creator.id", "=", "credits.cid")
            ->orderBy("credits.id", "DESC");
        if ($userRole != "admin") {
            $query->where("credits.user_id", $uid);
        }

        if (!empty($pdata["search"]["value"])) {
            $search = $pdata["search"]["value"];
            $search = trim($search);
            if (!empty($search)) {
                $query->where(function ($q) use ($search) {
                    $q->where("users.full_name", "LIKE", "%$search%")
                        ->orWhere("credits.desc",  "LIKE",  "%$search%");
                });
            }
            $pdata["search"]["value"] = "";
        }


        $DataTable      = new \App\Libraries\DataTable($query, $pdata);
        $result         = $DataTable->query()->toArray();

        $resData = array();
        $num = (!empty($pdata['start'])) ? $pdata['start'] : 0;

        foreach ($result as $item) {
            $num = $num + 1;
            $row = array();

            $createTime    = Jalalian::forge($item["ctime"]);

            $row['id']                  = $item["id"];
            $row['idx']                 = $num;
            $row['amount']              = $item["amount"];
            $row['operation']           = $item["operation"];
            $row['desc']                = $item["desc"];
            $row['user_name']           = $item["user_name"];
            $row['creator_name']        = $item["creator_name"];
            $row['amount']              = number_format($item["amount"]);
            $row['cdate']               = $createTime->format('Y/m/d');
            $row['ctime']               = $createTime->format('H:i');

            $resData[] = $row;
        }

        $result = $DataTable->make($resData);
        return $result;
    }
}
