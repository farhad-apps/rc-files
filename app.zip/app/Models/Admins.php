<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use Morilog\Jalali\Jalalian;

class Admins extends \App\Models\Users
{

    public function checkExist($id)
    {
        return $this->where("id", $id)->count();
    }

    public function saveUsers($pdata, $editId = null, $uid)
    {
        $columnsArr    = [];
        $pdata          = trimArrayValues($pdata);

        if (!empty($pdata["password"])) {
            $columnsArr["password"]     = password_hash($pdata["password"], PASSWORD_BCRYPT);
        }

        $columnsArr["full_name"]        = $pdata["full_name"];
        $columnsArr["role"]             = "admin";
        $columnsArr["username"]         = $pdata["username"];
        $columnsArr["status"]           = $pdata["status"];
        $columnsArr["status_desc"]      = "";
        $columnsArr["mobile"]           = getArrayValue($pdata, "mobile");
        $columnsArr["desc"]             = "";
        $columnsArr["unlimited"]        = 0;

        if (!$editId) {
            $columnsArr["credit"]           = 0;
            $columnsArr["ctime"]            = time();
            $columnsArr["utime"]            = 0;
            $columnsArr["cid"]              = $uid;
            $columnsArr["uid"]              = 0;
        } else {
            $columnsArr["uid"]              = time();
            $columnsArr["utime"]            = $uid;
        }

        $this->updateOrCreate(['id' => $editId], $columnsArr);
    }

    public function deleteUser($userId, $uid)
    {
        $this->where("id", $userId)->delete();
    }

    public function getTotalAdmins()
    {
        return $this->where("role", "admin")
            ->count();
    }

    public function dataTableList($pdata, $uid)
    {
        $select = ["users.*"];

        $query      = $this->select($select)->where("users.role", "admin");;

        $limitShow  = getTotalRowsInPlan("admins");
        if ($limitShow) {
            $sub        = clone $query;
            $subquery   = $sub->limit($limitShow);
            $query->joinSub($subquery, 'subquery', 'subquery.id', '=', 'users.id');
        }

        $DataTable      = new \App\Libraries\DataTable($query, $pdata);
        $users          = $DataTable->query()->toArray();

        $resUsers       = array();
        $num            = (!empty($pdata['start'])) ? $pdata['start'] : 0;

        foreach ($users as $user) {
            $num = $num + 1;
            $row = array();

            $row['id']                  = $user["id"];
            $row['idx']                 = $num;
            $row['username']            = $user["username"];
            $row['full_name']           = $user["full_name"];
            $row['mobile']              = $user["mobile"];
            $row['status']              = $user["status"];
            $row['ctime']               = Jalalian::forge($user["ctime"])->format('Y/m/d');
            $resUsers[] = $row;
        }

        $result = $DataTable->make($resUsers);
        return $result;
    }

    public function getFirstAdmin()
    {
        $query =  $this->where("role", "admin")
            ->where("status", "active")
            ->orderBy("id", "ASC")
            ->limit(1)
            ->get();
        if ($query->count()) {
            return  $query->first();
        }
        return false;
    }
}
