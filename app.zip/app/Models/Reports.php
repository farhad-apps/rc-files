<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Models;

use Morilog\Jalali\Jalalian;


class Reports extends \App\Models\BaseModel
{

    public function subscribers($days = 0, $role, $uid)
    {
        $startTime  = time() - (86400 * $days);
        $startTime  = strtotime("today", $startTime);

        $query =  db("users")->where("role", "subscriber")
            ->select("ctime", db()::raw("COUNT(id) as total"))
            ->where("ctime", ">", $startTime)
            ->groupByRaw(db()::raw("DATE(FROM_UNIXTIME(ctime))"))
            ->orderBy("ctime", "DESC");
        if ($role != "admin") {
            $query->where("users.cid", $uid);
        }

        $query  = $query->get();
        $rows   = false;
        if ($query->count()) {
            $rows   = $query->toArray();
        }

        $items  = $this->toPerDays($rows, $days);
        $items  = array_reverse($items);
        return $items;
    }

    public function resellersSubs($days = 0)
    {
        $resModel   = new \App\Models\Resellers();
        $resellers  = $resModel->getAllResellers();

        $resultRes  = [];
        $resIds     = [];
        if ($resellers) {
            foreach ($resellers  as $row) {
                $resIds[] = $row->id;
                $resultRes[$row->id] = [
                    "full_name" => $row->full_name,
                    "username" => $row->username,
                    "total"     => 0,
                ];
            }
        }

        $startTime  = time() - (86400 * $days);
        $startTime  = strtotime("today", $startTime);

        $query =  db("users")->where("role", "subscriber")
            ->select("cid", "ctime", db()::raw("COUNT(id) as total"))
            ->whereIn("cid", $resIds)
            ->groupBy("cid")
            ->orderBy("ctime", "DESC")
            ->get();
        if ($query->count()) {
            $rows = $query->toArray();
            foreach ($rows as $row) {
                if (isset($resultRes[$row->cid])) {
                    $resultRes[$row->cid]["total"] = $row->total;
                }
            }
        }

        $result = [];
        foreach ($resultRes as $res) {
            $fullName   = $res["full_name"];
            $username   = $res["username"];
            $key        = "$fullName ($username)";

            $result[$key] = $res["total"];
        }

        return $result;
    }



    private function toPerDays($items, $days = 7)
    {
        $out        = array();
        $time       = time();
        while ($days > 0) {
            $key = Jalalian::forge($time)->format("d F");
            $out[$key] = 0;
            $time -=  86400;
            $days -= 1;
        }

        if ($items) {
            foreach ($items as $key => $pdata) {
                $pkey = Jalalian::forge($pdata->ctime)->format("d F");
                if (isset($out[$pkey])) {
                    $out[$pkey] = $pdata->total;
                }
            }
        }

        return $out;
    }
}
