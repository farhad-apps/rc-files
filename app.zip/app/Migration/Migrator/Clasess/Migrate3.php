<?php

namespace App\Migration\Migrator\Clasess;

use App\Migration\Migrator\Abstractor;

class Migrate3 extends Abstractor
{

    function __construct($cont)
    {
        parent::__construct($cont);
    }

    public function description()
    {
        $desc = "Migrate 3 desc";
        return $desc;
    }

    public function check()
    {
        $this->checkExistMigrate();
        return $this;
    }

    public function run()
    {
        $this->cont->db::transaction(function () {
            $this->runSqlTable();
        });

        return $this;
    }

    public function verify()
    {
        return $this;
    }

    public function cleanUp()
    {
        return $this;
    }

    /** Private Methods */
    private function checkExistMigrate()
    {
        $prefix     = $this->dbConfig["prefix"];
        $tableName  = $prefix . "users_subs";
        $query      = $this->cont->db::select("SHOW COLUMNS FROM $tableName LIKE 'uuid'");
        if (!empty($query)) {
            throw new \Exception("Migrate2 has already been implemented");
        }
        return true;
    }


    private function runSqlTable()
    {
        loadHelpers("main");
        $prefix   = $this->dbConfig["prefix"];

        $result = $this->cont->db::transaction(function () use ($prefix) {

            //uuid id for users_online
            $tableName = $prefix . "users_subs";
            $sql = "ALTER TABLE $tableName ADD `uuid` varchar(512) NOT NULL AFTER `price`;";
            $this->cont->db::select($sql);

            $serversIds = [];
            $query = $this->cont->db->table("servers")
                ->get();
            if ($query->count()) {
                $rows = $query->toArray();
                foreach ($rows as $row) {
                    $serversIds[] = $row->id;
                }
            }

            $smetaValues = [];

            $query = $this->cont->db->table("servers_meta")
                ->get();
            if ($query->count()) {
                $rows = $query->toArray();
                $smetaValues = $rows;
                $this->cont->db->table("servers_meta")->delete();
            }

            //servers_meta
            $tableName = $prefix . "servers_meta";
            $sql = "ALTER TABLE $tableName AUTO_INCREMENT=1;";
            $this->cont->db::select($sql);

            $serversTbl = $prefix . "servers";
            $sql = "ALTER TABLE `$tableName` ADD  FOREIGN KEY (`server_id`) REFERENCES `$serversTbl`(`id`) ON DELETE CASCADE ON UPDATE NO ACTION;";
            $this->cont->db::select($sql);

            foreach ($smetaValues as $values) {
                $values = (array) $values;
                unset($values["id"]);
                if (in_array($values["server_id"], $serversIds)) {
                    $this->cont->db->table("servers_meta")
                        ->insert($values);
                }
            }

            //categories
            $tableName = $prefix . "categories";
            $sql = "ALTER TABLE $tableName ADD `protocol` varchar(50) NOT NULL AFTER `name`;";
            $this->cont->db::select($sql);

            //create uuid
            $query = $this->cont->db->table("users_subs")
                ->select("id")
                ->where("uuid", "=", "")
                ->get();
            if ($query->count()) {
                $rows = $query->toArray();
                foreach ($rows as $row) {
                    $id =  $row->id;
                    $this->cont->db->table("users_subs")->where("id", $id)->update([
                        "uuid" => createUuidV4Secure()
                    ]);
                }
            }

            return true;
        });

        if ($result !== true) {
            throw new \Exception("Migrate3 error");
        }
    }
}
