<?php

namespace App\Migration\Migrator\Clasess;

use App\Migration\Migrator\Abstractor;

class Migrate1 extends Abstractor
{

    function __construct($cont)
    {
        parent::__construct($cont);
    }

    public function description()
    {
        $desc = "Migrate 1 desc";
        return $desc;
    }

    public function check()
    {
        $this->checkExistMigrate();
        return $this;
    }

    public function run()
    {
        $this->cont->db::transaction(function () {
            $this->runSqlTable();
        });

        return $this;
    }

    public function verify()
    {
        return $this;
    }

    public function cleanUp()
    {
        return $this;
    }

    /** Private Methods */
    private function checkExistMigrate()
    {
        $prefix     = $this->dbConfig["prefix"];
        $query      = $this->cont->db::select("SHOW TABLES LIKE '" . $prefix . "categories'");
        if (!empty($query)) {
            throw new \Exception("Migrate1 has already been implemented");
        }
        return true;
    }


    private function runSqlTable()
    {
        $prefix   = $this->dbConfig["prefix"];

        $result = $this->cont->db::transaction(function () use ($prefix) {

            $catTable   = $prefix . "categories";
            $createSql  = " CREATE TABLE `$catTable` (
                `id` int(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                `name` varchar(50) NOT NULL,
                `cid` int(11) NOT NULL,
                `ctime` int(11) NOT NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";

            $this->cont->db::select($createSql);

            //category id for domains
            $tableName = $prefix . "domains";
            $sql = "ALTER TABLE $tableName ADD `category_id` int(11) NOT NULL AFTER `subdomain`;";
            $this->cont->db::select($sql);


            //category id for servers
            $tableName = $prefix . "servers";
            $sql = "ALTER TABLE $tableName ADD `category_id` int(11) NOT NULL AFTER `country_code`;";
            $this->cont->db::select($sql);

            //limit_online_users
            $sql = "ALTER TABLE $tableName ADD `limit_online_users` VARCHAR(30) NOT NULL AFTER `category_id`;";
            $this->cont->db::select($sql);

            //category id for users_subs
            $tableName = $prefix . "users_subs";
            $sql = "ALTER TABLE $tableName ADD `category_id` int(11) NOT NULL AFTER `package_id`;";
            $this->cont->db::select($sql);


            //servers_online_users_limit
            $this->cont->db->table("settings")->insert([
                "name" => "servers_online_users_limit",
                "value" => 0
            ]);

            return true;
        });

        if ($result !== true) {
            throw new \Exception("Migrate1 error");
        }
    }
}
