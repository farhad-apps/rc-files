<?php

namespace App\Migration\Migrator\Clasess;

use App\Migration\Migrator\Abstractor;

class Migrate2 extends Abstractor
{

    function __construct($cont)
    {
        parent::__construct($cont);
    }

    public function description()
    {
        $desc = "Migrate 2 desc";
        return $desc;
    }

    public function check()
    {
        $this->checkExistMigrate();
        return $this;
    }

    public function run()
    {
        $this->cont->db::transaction(function () {
            $this->runSqlTable();
        });

        return $this;
    }

    public function verify()
    {
        return $this;
    }

    public function cleanUp()
    {
        return $this;
    }

    /** Private Methods */
    private function checkExistMigrate()
    {
        $prefix     = $this->dbConfig["prefix"];
        $tableName  = $prefix . "users_online";
        $query      = $this->cont->db::select("SHOW COLUMNS FROM  $tableName  LIKE 'vpn_protocol'");
        if (!empty($query)) {
            throw new \Exception("Migrate2 has already been implemented");
        }
        return true;
    }


    private function runSqlTable()
    {
        $prefix   = $this->dbConfig["prefix"];

        $result = $this->cont->db::transaction(function () use ($prefix) {

            //vpn_protocol id for users_online
            $tableName = $prefix . "users_online";
            $sql = "ALTER TABLE $tableName ADD `vpn_protocol` varchar(100) NOT NULL AFTER `pid`;";
            $this->cont->db::select($sql);


            //vpn_protocol id for conn_logs
            $tableName = $prefix . "conn_logs";
            $sql = "ALTER TABLE $tableName ADD `vpn_protocol` varchar(100) NOT NULL AFTER `pid`;";
            $this->cont->db::select($sql);

            return true;
        });

        if ($result !== true) {
            throw new \Exception("Migrate2 error");
        }
    }
}
