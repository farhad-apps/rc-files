<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */
$sModel         = new \app\Models\Settings();

$app->group("", function () use ($app, $container) {

    $app->get('/',                          'App\Controllers\Front\Home:index');
    $app->get('/qrcode',                    'App\Controllers\Front\Home:qrcode');
    $app->get('/ovpn-config/{id}',          'App\Controllers\Front\Home:downloadOvpnConf');
    $app->get('/rpay-callback',             'App\Controllers\Front\Home:cbRenwalLicensePay');
    $app->get('/v2ray-sub/{uuid}',          'App\Controllers\Front\Home:genV2raySubs');

    $app->group("/user", function () use ($app, $container) {
        $app->get('[/]',        'App\Controllers\Front\User:login');
        $app->get('/{token}',   'App\Controllers\Front\User:index');
    })->add(new \App\Middlewares\UserAuth($container));


    $app->group('/ajax', function () use ($app) {
        $app->group("/login", function () use ($app) {
            $app->post('[/]',  'App\Controllers\Front\User:ajaxLogin');
        });
    });

    $app->group('/rocket-pro', function () use ($app) {
        $app->get('/req-license',   'App\Controllers\Front\Home:requestLicense');
        $app->get('/req-login',     'App\Controllers\Front\Home:requestLogin');
    })->add(new \App\Middlewares\RocketAuth($container));
    
});
