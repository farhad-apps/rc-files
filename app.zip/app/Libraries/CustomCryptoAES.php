<?php

namespace App\Libraries;

class CustomCryptoAES
{
    private $ivSize;
    private $iterations;
    private $key = '';

    public function __construct($ivSize = 16, $iterations = 9999)
    {
        $this->ivSize = $ivSize;
        $this->iterations = $iterations;
        $this->key = "NFPvtKxx2YuQiHyXs4T5lzDxpJepD8ln";
    }


    private function deriveIV()
    {
        // Use PBKDF2 to derive IV from the key
        $iv = hash_pbkdf2('sha256', $this->key, '', $this->iterations, $this->ivSize, true);
        return $iv;
    }

    private function fetchIV($encryptedTextWithIV)
    {
        // fetch IV from encrypted string with IV
        $iv = substr($encryptedTextWithIV, 0, $this->ivSize);
        $iv = str_pad($iv, $this->ivSize, '0', STR_PAD_LEFT);
        return $iv;
    }

    public function encrypt($plaintext)
    {
        $iv = $this->deriveIV();
        $ciphertext = openssl_encrypt($plaintext, 'AES-128-CBC', $this->key, OPENSSL_RAW_DATA, $iv);
        $encryptedText = $this->safeBase64Encode($iv . $ciphertext);
        return $encryptedText;
    }

    public function decrypt($encryptedText)
    {
        $encryptedTextWithIV = $this->safeBase64Decode($encryptedText);
        $iv = $this->fetchIV($encryptedTextWithIV);
        $ciphertext = substr($encryptedTextWithIV, $this->ivSize);
        $plaintext = openssl_decrypt($ciphertext, 'AES-128-CBC', $this->key, OPENSSL_RAW_DATA, $iv);
        return $plaintext;
    }

    public function safeBase64Encode($plainString)
    {
        $encoded = rtrim(strtr(base64_encode($plainString), '+/', '-_'), '=');
        return $encoded;
    }

    public function safeBase64Decode($encodedString)
    {
        $paddedData = str_pad($encodedString, strlen($encodedString) % 4, '=', STR_PAD_RIGHT);
        try {
            $decoded = base64_decode(strtr($paddedData, '-_', '+/'));
            return $decoded;
        } catch (\Exception $e) {
            return null;
        }
    }
}
