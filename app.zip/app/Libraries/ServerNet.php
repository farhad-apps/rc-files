<?php

namespace App\Libraries;

use phpseclib3\Net\SSH2;
use phpseclib3\Net\SFTP;

class ServerNet
{
    private $serverIp   = '';
    private $sshUser    = '';
    private $sshPort    = '';
    private $sshPass    = '';
    private $apiUrl   = "";

    private $sshInstance;
    private $ftpInstance;

    public function __construct()
    {
        $this->apiUrl = baseUrl("sapi");
    }

    public function setConfig($serverIp, $sshUser,  $sshPass, $sshPort)
    {
        $this->serverIp = $serverIp;
        $this->sshUser  = $sshUser;
        $this->sshPort  = $sshPort;
        $this->sshPass  = $sshPass;
    }


    public function login()
    {
        $ssh = new SSH2($this->serverIp, $this->sshPort);

        if (!$ssh->login($this->sshUser, $this->sshPass)) {
            throw new \Exception('Login failed');
        }
        $ssh->setTimeout(0);

        $this->sshInstance = $ssh;

        $sftp = new SFTP($this->serverIp, $this->sshPort);
        $sftp->login($this->sshUser, $this->sshPass);

        $this->ftpInstance = $sftp;
    }

    public function disconnect()
    {
        $this->sshInstance->disconnect();
        $this->ftpInstance->disconnect();
    }

    public function restartSSH()
    {
        $this->runCommand("sudo service ssh restart");
        $this->runCommand("sudo service sshd restart");
    }

    public function createUserBannerFile($username, $html)
    {
        $this->ftpInstance->put("/var/ssh-banners/$username", $html);
    }

    public function fillRocketSshdContent($fileContent)
    {
        $this->ftpInstance->put("/etc/ssh/rocket_sshd_config", $fileContent);
    }

    public function getRocketSshdContent()
    {
        $this->ftpInstance->get("/etc/ssh/rocket_sshd_config");
    }

    public function removeUserBanner($username)
    {
        $fileContent    = $this->ftpInstance->get("/etc/ssh/rocket_sshd_config");
        $lines          = preg_split("/\r\n|\n|\r/", $fileContent);
        $removLines     = ["Match User $username", "Banner /var/ssh-banners/$username"];

        $newLines = [];
        foreach ($lines as $line) {
            if (!in_array(trim($line), $removLines)) {
                $newLines[] = $line;
            }
        }

        $mergedLines = array();
        $consecutiveEmptyLines = 0;

        foreach ($newLines as $line) {
            if (trim($line) === '') {
                $consecutiveEmptyLines++;
                if ($consecutiveEmptyLines <= 2) {
                    $mergedLines[] = $line;
                }
            } else {
                $consecutiveEmptyLines = 0; // Reset the count of consecutive empty lines
                $mergedLines[] = $line;
            }
        }

        $fileContent = implode("\n", $mergedLines);
        $this->ftpInstance->put("/etc/ssh/rocket_sshd_config", $fileContent);
        $this->runCommand("rm /var/ssh-banners/$username");
    }

    public function resetRocketApp()
    {
        $this->runCommand('supervisorctl restart rocketApp');
    }
    
    public function updateRocketApp()
    {
        $this->runCommand('/var/rocket-ssh/installer update-rocket-app');
    }
    
    public function rebootServer()
    {
        $this->runCommand('reboot');
    }

    public function getCpuType()
    {
        $result =  $this->runCommand("uname -m");
        $result = trim($result);
        $result = strtolower($result);
        if ($result == "x86_64") {
            return "x86";
        }
        return "arm";
    }

    public function getOsName()
    {
        $out = $this->runCommand("lsb_release -si");
        return $this->snaitizeCmdOut($out);
    }

    public function getOsVersion()
    {
        $command = 'grep VERSION_ID /etc/os-release | cut -d= -f2 | tr -d \'"\'';
        $out = $this->runCommand($command);
        return $this->snaitizeCmdOut($out);
    }

    public function startConfiguration($configsArr)
    {

        $this->runCommand("rm -R /var/rocket-ssh");
        $this->runCommand("mkdir /var/rocket-ssh");
        $this->runCommand("mkdir /lib/security");
        $this->runCommand("echo 'start' > /var/rocket-ssh/status.txt");

        $this->setupConfigFile($configsArr);

        $cpuType        = $this->getCpuType();
        $installFile    = "installer-$cpuType";

        $installerUrl   = "https://raw.githubusercontent.com/pro-apps-1/files/main/pro-files/$installFile";

        $this->runCommand('wget -O /var/rocket-ssh/installer "' . $installerUrl . '"');
        $this->runCommand("chmod +x /var/rocket-ssh/installer");

        $this->runCommand("/var/rocket-ssh/installer default-setup > /var/rocket-ssh/main-setup.log 2>&1 &");
    }

    public function setupConfigFile($configsArr)
    {
        $serverFolderPath = "/var/rocket-ssh/";
        $jfilePath      = $serverFolderPath . "configs.json";
        $this->ftpInstance->put($jfilePath, json_encode($configsArr, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    }

    public function uploadOvpnCerts($filePath)
    {
        $serverFolderPath = "/etc/openvpn/certs.zip";
        if ($this->ftpInstance->put($serverFolderPath, $filePath, SFTP::SOURCE_LOCAL_FILE)) {
            $this->runCommand("unzip -o $serverFolderPath -d /etc/openvpn");
            
            $this->runCommand("rm $serverFolderPath");
            $this->runCommand("systemctl restart openvpn");
            $this->runCommand("bash /etc/openvpn/gen-client-conf.sh");
        }
    }

    public function getConfigurationStatus()
    {
        $filePath   = "/var/rocket-ssh/status.txt";
        $isExist    = $this->ftpInstance->file_exists($filePath);
        $status     = "";

        if ($isExist) {
            $status = $this->ftpInstance->get($filePath);
        }
        $status = str_replace("\n", '', $status);
        $status = trim($status);
        return $status;
    }

    public function getConfigurationLog()
    {
        $filePath   = "/var/rocket-ssh/main-setup.log";
        $isExist    = $this->ftpInstance->file_exists($filePath);
        $result     = "";
        if ($isExist) {
            $result = $this->ftpInstance->get($filePath);
        }
        return $result;
    }

    public function removeConfigurationStatusFile()
    {
        $filePath = "/var/rocket-ssh/status.txt";
        $this->ftpInstance->delete($filePath);
    }

    public function runCommand($command)
    {
        return $this->sshInstance->exec($command);
    }

    private function snaitizeCmdOut($out)
    {
        $out = str_replace("\n", '', $out);
        return trim($out);
    }
}
