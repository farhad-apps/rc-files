<?php

namespace App\Libraries;

class CheckHostApi
{

    private $host  = "";
    private $requestId  = "";
    private $apiUrl = "https://check-host.net";

    public function __construct($host = "")
    {
        $this->host = $host;
    }

    public function setHost($host)
    {
        $this->host = $host;
    }

    public function setRequestId($requestId)
    {
        $this->requestId = $requestId;
    }

    public function getRequestId($type = "check-tcp")
    {
        $apiUrl = $this->apiUrl;
        $host   = $this->host;
        $url    = "$apiUrl/$type/?host=$host";

        $curl   = curl_init();

        $options = [
            CURLOPT_URL             => $url,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_ENCODING        => '',
            CURLOPT_MAXREDIRS       => 10,
            CURLOPT_TIMEOUT         => 0,
            CURLOPT_FOLLOWLOCATION  => true,
            CURLOPT_HTTP_VERSION    => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST   => 'GET',
            CURLOPT_HTTPHEADER      => ['Accept: application/json'],
        ];

        curl_setopt_array($curl, $options);
        $response = curl_exec($curl);
        curl_close($curl);

        if (!empty($response)) {
            $response = json_decode($response, true);
            if (!empty($response["request_id"])) {
                $this->requestId = $response["request_id"];

                return $response["request_id"];
            }
        }
        return false;
    }

    public function checkResult()
    {
        $apiUrl = $this->apiUrl;
        $reqId  = $this->requestId;
        $url    = "$apiUrl/check-result/$reqId";

        $curl   = curl_init();

        $options = [
            CURLOPT_URL             => $url,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_ENCODING        => '',
            CURLOPT_MAXREDIRS       => 10,
            CURLOPT_TIMEOUT         => 0,
            CURLOPT_FOLLOWLOCATION  => true,
            CURLOPT_HTTP_VERSION    => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST   > 'GET',
            CURLOPT_HTTPHEADER => [
                'Accept: application/json'
            ],
        ];
        curl_setopt_array($curl, $options);

        $response = curl_exec($curl);

        curl_close($curl);

        if (!empty($response)) {
            $response = json_decode($response, true);
            if (!empty($response)) {
                return $response;
            }
        }

        return false;
    }


    public function parseResponse($response, $countries = ["ir", "us", "fr", "de"])
    {
        $result = [];
        if (!empty($response)) {
            foreach ($response as $key => $value) {

                $flag = str_replace(".node.check-host.net", "", $key);
                $flag = preg_replace("/[0-9]+/", "", $flag);

                if (in_array($flag, $countries)) {
                    if (!empty($value[0]["time"])) {
                        $status = "online";
                    } else {
                        $status = "filter";
                    }

                    $result[] = [
                        "flag"      => $flag,
                        "flag_img"  => assets("images/flags/$flag.png"),
                        "status"    => $status,
                        "name"      => convertFlagName($flag)
                    ];
                }
            }
        }
        return  $result;
    }
}
