<?php

namespace App\Libraries;

class ServerApi
{

    private $serverIp = "";

    public function __construct($ip)
    {
        $this->serverIp = $ip;
    }

    public function setIpAddress($serverIp)
    {
        $this->serverIp = $serverIp;
    }

    public function createUsers($users)
    {
        $pdata = [
            "users"     => $users,
            "action"    => "create-users",
        ];

        $this->sendApi($pdata);
    }

    public function updateUsers($users)
    {
        $pdata = [
            "users"      => $users,
            "action"     => "update-users",
        ];

        $this->sendApi($pdata);
    }

    public function downloadOvpnUconfig()
    {
        $pdata = [
            "action"     => "ovpn-client-conf",
        ];

        return $this->sendApi($pdata);
    }

    public function removeUsers($users)
    {
        $pdata = [
            "users"     => $users,
            "action"    => "remove-users",
        ];

        $this->sendApi($pdata);
    }

    public function killUsers($users)
    {
        $pdata = [
            "users"     => $users,
            "action"    => "kill-users",
        ];

        $this->sendApi($pdata);
    }

    public function killUserByPid($protocol, $userIp, $pid)
    {
        $pdata = [
            "protocol"  => $protocol,
            "user_ip"   => $userIp,
            "pid"       => $pid,
            "action"    => "kill-upid",
        ];
        $this->sendApi($pdata);
    }

    public function installProtocol($protocol)
    {
        $pdata = [
            "action"    => "setup-protocols",
            "protocol"  => $protocol,
        ];

        return $this->sendApi($pdata);
    }

    public function getInstallProtocolLog($protocol)
    {
        $pdata = [
            "protocol"  => $protocol,
        ];
        return  $this->sendApi($pdata);
    }

    public function getResources()
    {
        $pdata = [
            "action"    => "sys-data",
        ];

        return $this->sendApi($pdata, 15);
    }

    public function execCommand($command)
    {
        $pdata = [
            "action"    => "exec-command",
            "command"   => $command,
        ];

        return $this->sendApi($pdata);
    }

    public function downloadFile($path)
    {
        $pdata = [
            "action"    => "download-file",
            "file_path" => $path,
        ];

        return $this->sendApi($pdata);
    }

    private function sendApi($pdata = [], $timeout = 300)
    {
        $url    = "http://$this->serverIp/papi";

        $curl   = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL             => $url,
            CURLOPT_POST            => 1,
            CURLOPT_RETURNTRANSFER  => true,
            CURLOPT_SSL_VERIFYPEER  => false,
            CURLOPT_SSL_VERIFYHOST  => false,
            CURLOPT_CONNECTTIMEOUT  => 15,
            CURLOPT_TIMEOUT         => $timeout,
            CURLOPT_CUSTOMREQUEST   => 'POST',
            CURLOPT_POSTFIELDS      => json_encode($pdata),
            CURLOPT_HTTPHEADER      => [
                'x-auth: p5c23cb5nopit1ak3g6nbfqv84hewl',
                'Content-Type: application/json'
            ],
        ));

        $response = curl_exec($curl);
        $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        if (curl_errno($curl)) {
            throw new \Exception("curl_error");
        }

        curl_close($curl);

        if ($httpcode == 200) {
            if (!empty($response)) {
                if (isJson($response)) {
                    return json_decode($response, true);
                }
                return $response;
            }
        } else {
            // throw new \Exception("Error");
        }
    }
}
