<?php

function adminViewContents($viewFile)
{
    return PATH_APP . DS . "Views" . DS . "Admin" . DS . $viewFile;
}

function adminLoadViewSection($path)
{
    $fullPath = PATH_APP . DS . "Views" . DS . "Admin" . DS . $path;
    if (file_exists($fullPath)) {
        include $fullPath;
    }
}


function moveUploadedFile($directory, $uploadedFile, $filename = "")
{
    $extension  = pathinfo($uploadedFile->getClientFilename(), PATHINFO_EXTENSION);
    if (!$filename) {
        $basename   = bin2hex(random_bytes(8));
        $filename   = sprintf('%s.%0.8s', $basename, $extension);
    } else {
        $filename = "$filename.$extension";
    }
    $uploadedFile->moveTo($directory . DS . $filename);
    return $filename;
}

function addSysLog($logType, $logDesc, $cid)
{

    $l = new \App\Models\SysLogs();
    $l->addLog($logType, $logDesc, $cid);
}


function translateSysLog($logType)
{
    $ltypes = [
        "add_subscriber"        => "افزودن مشترک",
        "edit_subscriber"       => "ویرایش مشترک",
        "renewal_subscriber"    => "تمدید مشترک",
        "inactive_subscriber"   => "غیر فعال کردن مشترک",
        "active_subscriber"     => "فعال کردن مشترک",
        "delete_subscriber"     => "حذف مشترک",
        "kill_subscriber"       => "اخراج مشترک",
    ];
    if (!empty($ltypes[$logType])) {

        return $ltypes[$logType];
    }
    return "";
}


function getInstalledProtocolsLogs($logContent)
{
    // Define the words to search for
    $words = ['installed_ssh', 'installed_openvpn', 'installed_v2ray'];
    // Initialize an associative array to store the results
    $result = [
        "installed_ssh"     => false,
        "installed_openvpn" => false,
        "installed_v2ray"   => false,
    ];

    // Iterate through the words and check if they are present in the file
    foreach ($words as $word) {
        // Use regex to search for the word in the file content
        $pattern = '/' . preg_quote($word, '/') . '/i'; // 'i' flag for case-insensitive search
        $result[$word] = preg_match($pattern, $logContent) === 1;
    }

    // Return the result array
    return $result;
}



function getZipFiles($filePath)
{
    $zip        = new \ZipArchive;
    $fileList   = [];
    if ($zip->open($filePath) === TRUE) {

        for ($i = 0; $i < $zip->numFiles; $i++) {
            $fileList[] = $zip->getNameIndex($i);
        }
        $zip->close();
    }

    return $fileList;
}

function translateLicense($license)
{
    $arrayLicense = [
        "free"      => "رایگان",
        "bronze"    => "برنزی",
        "silver"    => "نقره ای",
        "gold"      => "طلایی",
        "brillant" => "برلیان",
    ];

    if (isset($arrayLicense[$license])) {
        return $arrayLicense[$license];
    }

    return $license;
}


function generatePassword($len = 8) {
    $lowercaseLetters = "abcdefghijklmnopqrstuvwxyz123456789";
    $password = "";

    for ($i = 0; $i < $len; $i++) {
        $randomIndex = rand(0, strlen($lowercaseLetters) - 1);
        $password .= $lowercaseLetters[$randomIndex];
    }

    return $password;
}