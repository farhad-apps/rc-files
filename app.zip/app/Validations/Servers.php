<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Validations;

class Servers
{

    public static function save($pdata, $editId = null)
    {

        $result     = array("status" => "success", "messages" => []);
        $sModel     = new \App\Models\Servers();

        $serverInfo  = null;
        if ($editId) {
            $serverInfo =  $sModel->getInfo($editId);
            if (!$serverInfo) {
                $result["status"] = "error";
                $result["messages"][] = "اطلاعات سرور یافت نشد";
                return $result;
            }
        } else {
            $hasCreate = hasActionInPlan("new-server");
            if (!$hasCreate) {
                $result["status"] = "error";
                $result["messages"][] = "شما مجاز به افزودن سرور جدید نمی باشید";
                return $result;
            }
        }

        $validatorRules = [
            'name'                  => ['required'],
            'ssh_user'              => ['required'],
            'ssh_pass'              => ['required'],
            'ssh_port'              => ['required'],
            'country_code'          => ['required'],
            'country_code'          => ['required'],

        ];

        if (!$editId) {
            $validatorRules['ip'] = [
                'required',
                function ($attribute, $value,  $fail) use ($sModel, $editId) {
                    if ($value) {
                        if ($sModel->isExistIp($value, $editId)) {
                            $fail("لطفا از آی پی دیگری استفاده کنید");
                        }
                    }
                },
            ];
            $validatorRules['protocols'] = ['required', 'array', 'in:ssh,v2ray,openvpn'];
        }


        if (!empty($pdata["protocols"])) {

            $validatorRules['protocols'] = ['required', 'array', 'in:ssh,v2ray,openvpn'];

            $protocols = $pdata["protocols"];
            if (in_array("ssh", $protocols)) {
                $validatorRules['ssh_category'] = ["required"];
            }
            if (in_array("v2ray", $protocols)) {
                $validatorRules['v2ray_category'] = ["required"];
            }
            if (in_array("openvpn", $protocols)) {
                $validatorRules['openvpn_category'] = ["required"];
            }
        }

        $validatorMsg = [
            'name.required'             => 'عنوان سرور را وارد کنید',
            'ip.required'               => 'آیپی سرور را وارد کنید',
            'ssh_user.required'         => 'یوزر ssh سرور را وارد کنید',
            'ssh_pass.required'         => 'رمز ssh سرور را وارد کنید',
            'ssh_port.required'         => 'پورت ssh سرور را وارد کنید',
            'country_code.required'     => 'انتخاب کشور را وارد کنید'
        ];

        $validation = validator()->make(
            $pdata,
            $validatorRules,
            $validatorMsg
        );

        if ($validation->fails()) {
            $messages = $validation->errors()->getMessages();
            $messages[]                 = "لطفا ورودی های خود را کنترل کنید";
            $result["messages"]         = array_reverse($messages);
            $result["error_fields"]     = array_keys($messages);
            $result["status"]           = "error";
        } else {
            $serverNet = new  \App\Libraries\ServerNet();

            $ip        = $pdata["ip"];
            $sshUser   = $pdata["ssh_user"];
            $sshPass   = $pdata["ssh_pass"];
            $sshPort   = $pdata["ssh_port"];

            try {
                $serverNet->setConfig($ip, $sshUser, $sshPass, $sshPort);
                $serverNet->login();
                $osName     = $serverNet->getOsName();
                $osVersion  = $serverNet->getOsVersion();

                if ($osName != "Ubuntu" || $osVersion != "22.04") {
                    $os = "$osName $osVersion";
                    throw new \Exception("سیستم عامل سرور حتما باید Ubuntu 22.04 باشد. سیستم عامل سرور شما: $os");
                }
            } catch (\Exception $err) {
                $result["messages"]  = $err->getMessage();
                $result["status"]    = "error";
            }
        }

        return $result;
    }



    public static function hasExist($serverId)
    {
        $result = array("status" => "success", "messages" => []);

        $uModel = new \App\Models\Servers();
        $hasExist = $uModel->checkExist($serverId);

        if (!$hasExist) {
            $result["status"] = "error";
            $result["messages"][] = "اطلاعات سرور یافت نشد";
        }
        return $result;
    }

    public static function hasRunAction($serverId)
    {
        $result = array("status" => "success", "messages" => []);

        $sModel    = new \App\Models\Servers();
        $hasExist  = $sModel->checkExist($serverId);

        if (!$hasExist) {
            $result["status"] = "error";
            $result["messages"][] = "اطلاعات سرور یافت نشد";
        } else {
            try {
                $sModel->checkLogin($serverId);
            } catch (\Exception $err) {
                $result["status"] = "error";
                $result["messages"]  = "ارتباط با سرور برقرار نشد. اطلاعات ورودی را بررسی کنید";
            }
        }

        return $result;
    }

    public static function delete($serverId, $uid)
    {
        $result = array("status" => "success", "messages" => []);

        $uModel = new \App\Models\Servers();
        $hasExist = $uModel->checkExist($serverId);

        if (!$hasExist) {
            $result["status"] = "error";
            $result["messages"][] = "اطلاعات سرور یافت نشد";
        }

        return $result;
    }
}
