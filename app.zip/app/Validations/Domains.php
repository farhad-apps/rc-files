<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Validations;

class Domains
{

    public static function saveDomains($pdata)
    {
        $result     = array("status" => "success", "messages" => []);

        $sModel     = new \App\Models\Settings();
        $clToekn    = $sModel->getSetting("cloudflare_token");

        $validatorRules = [
            'subdomain'    => ['required'],
            'category'     => ['required', function ($attribute, $value,  $fail) {
                if ($value) {
                    $cModel = new \App\Models\Categories();
                    $res = $cModel->checkExist($value);
                    if(!$res ){
                        $fail("اطلاعات دسته بندی یافت نشد");
                    }
                }
            }],
        ];
        if ($clToekn) {
            $subdomain = !empty($pdata["subdomain"]) ? $pdata["subdomain"] : "";
            $validatorRules["zone_id"] = [
                'required',
                function ($attribute, $value,  $fail) use ($clToekn, $subdomain) {
                    if ($value) {
                        $clApi = new \App\Libraries\CloudflareApi($clToekn);
                        try {
                            $result = $clApi->checkZoneId($value);
                            $name   = $result["result"]["name"];
                            if (!isValidSubdomain($subdomain, $name)) {
                                $fail("ساب دامنه وارد شده با اطلاعات کلوفر همخوانی ندارد");
                            }
                        } catch (\Exception $err) {
                            $fail("Zone ID وارد شده صحیح نیست");
                        }
                    }
                }
            ];
        }

        $validatorMsg = [
            'subdomain.required'    => 'لینک ساب دامنه را وارد کنید',
            'zone_id.required'      => 'شناسه زون را وارد کنید',
        ];

        $validation = validator()->make(
            $pdata,
            $validatorRules,
            $validatorMsg
        );

        if ($validation->fails()) {
            $messages = $validation->errors()->getMessages();
            $messages[]                 = "لطفا ورودی های خود را کنترل کنید";
            $result["messages"]         = array_reverse($messages);
            $result["error_fields"]     = array_keys($messages);
            $result["status"]           = "error";
        }

        return $result;
    }

    public static function hasExist($id)
    {
        $result = array("status" => "success", "messages" => []);

        $dModel = new \App\Models\Domains();
        $hasExist = $dModel->checkExist($id);

        if (!$hasExist) {
            $result["status"] = "error";
            $result["messages"][] = "اطلاعات دامنه یافت نشد";
        }
        return $result;
    }

    public static function delete($manId, $uid)
    {
        $result = array("status" => "success", "messages" => []);

        $dModel = new \App\Models\Domains();
        $hasExist = $dModel->checkExist($manId);

        if (!$hasExist) {
            $result["status"] = "error";
            $result["messages"][] = "اطلاعات دامنه یافت نشد";
        }

        return $result;
    }
}
