<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Validations;

class Packages
{


    public static function save($pdata, $editId = null, $uid = null)
    {
        $result     = array("status" => "success", "messages" => []);
        $pModel     = new \App\Models\Packages();

        $userInfo  = null;
        if ($editId) {
            $userInfo =  $pModel->getInfo($editId);
            if (!$userInfo) {
                $result["status"] = "error";
                $result["messages"][] = "اطلاعات پکیج یافت نشد";
                return $result;
            }
        }

        $validatorRules = [
            'name'              => ['required'],
            'validity_days'     => ['required', 'numeric', 'min:0'],
            'limit_users'       => ['required', 'numeric', 'min:1'],
            'price'             => ['required'],
            'is_disabled'       => ['required', 'in:0,1'],
            'start_time_type'   => ['required', 'in:first-conn,create-user'],
            'traffic'           => ['required', 'numeric'],
        ];


        $validatorMsg = [
            'name.required'             => 'نام را وارد کنید',
            'validity_days.required'    => 'تعداد روز را وارد کنید',
            'limit_users.required'      => 'تعداد کاربر همزمان را وارد کنید',
            'traffic.required'          => 'مقدار ترافیک را وارد کنید',
            'start_time_type.required'  => 'نوع زمان شروع را وارد کنید',
            'price.required'            => 'قیمت را وارد کنید',
            'is_disabled.required'      => 'وضعیت را وارد کنید',
        ];

        $validation = validator()->make(
            $pdata,
            $validatorRules,
            $validatorMsg
        );

        if ($validation->fails()) {
            $messages = $validation->errors()->getMessages();
            $messages[]                 = "لطفا ورودی های خود را کنترل کنید";
            $result["messages"]         = array_reverse($messages);
            $result["error_fields"]     = array_keys($messages);
            $result["status"]           = "error";
        }

        return $result;
    }

    public static function hasExist($pid)
    {
        $result = array("status" => "success", "messages" => []);

        $aModel = new \App\Models\Packages();
        $hasExist = $aModel->checkExist($pid);

        if (!$hasExist) {
            $result["status"] = "error";
            $result["messages"][] = "اطلاعات پکیج  یافت نشد";
        }
        return $result;
    }
}
