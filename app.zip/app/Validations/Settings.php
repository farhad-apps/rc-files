<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Validations;

use Illuminate\Validation\Rules\File;

class Settings
{

    public function saveServersSettings($pdata)
    {

        $result     = array("status" => "success", "messages" => []);

        $validatorRules = [
            'servers_ssh_port'     => ['required', 'numeric', 'min:2'],
            'servers_udp_port'     => ['required', 'numeric', 'min:4'],
        ];

        $validatorMsg = [
            'servers_ssh_port.required' => 'پورت ssh را وارد کنید',
            'servers_ssh_port.numeric'  => 'پورت ssh را به صورت عددی وارد کنید',
            'servers_ssh_port.min'      => 'پورت ssh حداقل باید از دورقم تشکیل شده باشد',

            'servers_udp_port.required' => 'پورت udp را وارد کنید',
            'servers_udp_port.numeric'  => 'پورت udp را به صورت عددی وارد کنید',
            'servers_udp_port.min'      => 'پورت udp حداقل باید از چهار رقم تشکیل شده باشد',

            'servers_token.required'    => "توکن سرورها را وارد کنید",
            'servers_token.min'         => 'توکن حداقل باید 30 کاراکتر باشد',

        ];

        if (!empty($pdata["servers_token"])) {
            $validation["servers_token"] = ['required', 'min:30'];
        }
        if (!empty($pdata["servers_ovpn_port"])) {
            $validation["servers_ovpn_port"] = ['required', 'numeric'];
        }
        
        if (!empty($pdata["servers_auth_file"])) {
            $file = $pdata["servers_auth_file"];
            if (is_object($file) && $file->getClientFilename()) {
                $validatorRules['servers_auth_file'] = [
                    'required',
                    function ($attribute, $value,  $fail) {
                        try {
                            $filename =  $value->getClientFilename();
                            $ext = pathinfo($filename, PATHINFO_EXTENSION);
                            if ($ext != "so") {
                                $fail("لطفا فایل مجوز را به صورت صحیح ارسال کنید");
                            }
                        } catch (\Exception $err) {
                            $fail("لطفا فایل مجوز را به صورت صحیح ارسال کنید");
                        }
                    },
                ];
            }
        }


        $validation = validator()->make(
            $pdata,
            $validatorRules,
            $validatorMsg
        );

        if ($validation->fails()) {
            $messages = $validation->errors()->getMessages();
            $messages[]                 = "لطفا ورودی های خود را کنترل کنید";
            $result["messages"]         = array_reverse($messages);
            $result["error_fields"]     = array_keys($messages);
            $result["status"]           = "error";
        }

        return $result;
    }


    public function saveDomains($pdata)
    {
    }

    public function checkTelegramBot($pdata)
    {
        $result     = array("status" => "success", "messages" => []);

        $validatorRules = [
            'token'     => ['required', function ($attr, $value,  $fail) {
                if ($value) {
                    $bot = new \App\Libraries\Telegram($value);
                    $res = $bot->getMe();
                    if (!empty($res) && $res["ok"] == 1) {
                    } else {
                        $fail("توکن وارد شده صحیح نیست");
                    }
                }
            }],
        ];

        $validatorMsg = [
            'token.required' => 'وارد کردن توکن ربات الزامی است',
        ];

        $validation = validator()->make(
            $pdata,
            $validatorRules,
            $validatorMsg
        );

        if ($validation->fails()) {
            $messages = $validation->errors()->getMessages();
            $messages[]                 = "لطفا ورودی های خود را کنترل کنید";
            $result["messages"]         = array_reverse($messages);
            $result["error_fields"]     = array_keys($messages);
            $result["status"]           = "error";
        }

        return $result;
    }

    public function importBackup($pdata)
    {

        $result     = array("status" => "success", "messages" => []);

        $validatorRules = [
            'file' => [
                'required', function ($attribute, $file,  $fail) {
                    if ($file && !empty($file->getClientFilename())) {
                        $extension = strtolower(pathinfo($file->getClientFilename(), PATHINFO_EXTENSION));
                        $hasErro = $file->getError();
                        if ($hasErro ||  $extension !== "sql") {
                            $fail("لطفا یک فایل sql صحیح ارسال کنید");
                        }
                    }
                },
            ],
            "import_from" => ["required", "in:current,rokcet_single_server"]
        ];


        $validatorMsg = [
            'file.required'         => 'فایلی جهت ایمپورت ارسال کنید',
            'import_from.required'  => 'نوع پنل را انتخاب کنید',
            'import_from.in'        => 'نوع پنل انتخابی صحیح نیست',
        ];

        $validation = validator()->make(
            $pdata,
            $validatorRules,
            $validatorMsg
        );


        if ($validation->fails()) {
            $messages = $validation->errors()->getMessages();
            $messages[]                 = "لطفا ورودی های خود را کنترل کنید";
            $result["messages"]         = array_reverse($messages);
            $result["error_fields"]     = array_keys($messages);
            $result["status"]           = "error";
        }

        return $result;
    }
}
