<?php

/**
 * By RocketAp
 * Github: https://github.com/rocket-ap
 */

namespace App\Middlewares;

class UserAuth
{

    private $cont;
    private $excludeListStatic = array(
        'user'
    );
    private $excludeListPattern = array();

    function __construct($container)
    {
        $this->cont = $container;
    }

    private function excludeCheck($uri)
    {
        if (in_array($uri, $this->excludeListStatic)) {
            return true;
        }
        // dynamic rule check
        foreach ($this->excludeListPattern as $pattern) {
            if (preg_match("|^" . $pattern . "|is", $uri)) {
                return true;
            }
        }
        return false;
    }


    public function __invoke($request, $response, $next)
    {
        $uri            = $request->getUri()->getPath();
        $uri            = ltrim($uri, '/');
        $pass = false;

        if ($this->excludeCheck($uri)) {
            $pass = true;
        } else {
            $uriArr = explode("/", $uri);
            $token  = end($uriArr);
            if ($token) {
                $subsModel = new \App\Models\UsersSubs();
                $result = $subsModel->checkUserToken($token);
                if ($result) {
                    $request = $request->withAttribute('user_id', $result->user_id);
                    $pass = true;
                }
            }
        }
        if ($pass) {
            $response = $next($request, $response);
            return $response;
        }

        return $response->withStatus(302)->withHeader("location", baseUrl("user"));
    }
}
