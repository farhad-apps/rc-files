<?php
ini_set('memory_limit', '256M');
ini_set('max_execution_time', '1000');

$baseUrl    = (isset($_SERVER['HTTPS']) ? "https://" : "http://") . $_SERVER['HTTP_HOST'] .  str_replace(basename($_SERVER['SCRIPT_NAME']), '', $_SERVER['SCRIPT_NAME']);
$pdata      = $_POST;

function downloadFile($url, $destination)
{
    $content = @file_get_contents($url);
    @file_put_contents($destination, $content);
}

function deleteFolder($folderPath)
{
    if (is_dir($folderPath)) {
        $files = glob($folderPath . '/*');
        foreach ($files as $file) {
            is_dir($file) ? deleteFolder($file) : unlink($file);
        }
        rmdir($folderPath);
    }
}

function getZipFolderNames($zipFilePath)
{
    $zip = new ZipArchive;
    if ($zip->open($zipFilePath) === true) {
        $folderNames = [];
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $fileInfo = $zip->statIndex($i);
            if ($fileInfo['size'] === 0 && substr($fileInfo['name'], -1) === '/') {
                $folderNames[] = ($fileInfo['name']);
            }
        }
        $zip->close();
        return $folderNames;
    }
    return [];
}

function moveFolder($source, $destination)
{
    if (is_dir($source)) {
        @mkdir($destination, 0755, true);
        $files = glob($source . '/*');
        foreach ($files as $file) {
            is_dir($file) ? moveFolder($file, $destination . '/' . basename($file)) : rename($file, $destination . '/' . basename($file));
        }
        rmdir($source);
    }
}

function callMigrateUrl()
{
    global $baseUrl;

    $url = "$baseUrl" . "migrate";
    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL             => $url,
        CURLOPT_RETURNTRANSFER  => true,
        CURLOPT_ENCODING        => '',
        CURLOPT_MAXREDIRS       => 10,
        CURLOPT_TIMEOUT         => 0,
        CURLOPT_FOLLOWLOCATION  => true,
        CURLOPT_HTTP_VERSION    => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST   => 'GET',
    ));
    $response = curl_exec($curl);
    curl_close($curl);
}

function getZipUrl()
{
    $zipUrl = 'https://github.com/pro-apps-1/files/raw/main/app.zip';
    return $zipUrl;
}

if (!empty($pdata["update"])) {
    $result = ["status" => "success"];
    $pass   = true;

    $zipUrl             = getZipUrl();
    $downloadedZipFile  = __DIR__ . '/update.zip';
    $extractPath        = __DIR__;

   downloadFile($zipUrl, $downloadedZipFile);

    if (!file_exists($downloadedZipFile)) {
        $result["status"] = "error";
        $result["message"] = "دانلود فایل با خطا مواجه شد";
        $pass = false;
    }

    if ($pass) {

        $zip = new ZipArchive;
        if ($zip->open($downloadedZipFile) === true) {
            // Extract the contents of the zip file to the project root
            $zip->extractTo($extractPath);
            $zip->close();

            sleep(1);
            callMigrateUrl();
        } else {
            $result["status"] = "error";
            $result["message"] = "عملیات آپدیت با خطا مواجه شد";
            $pass = false;
        }
    }
    @unlink($downloadedZipFile);
    echo json_encode($result);
    exit;
}

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>آپدیت پنل</title>
    <link rel="stylesheet" href="<?= $baseUrl . "assets/css/app.css" ?>">
    <link rel="stylesheet" href="<?= $baseUrl . "assets/fonts/webfont.css" ?>">

    <style>
        .main-content {
            max-width: 700px;
            padding: 1rem;
        }
    </style>
</head>

<body class="d-flex align-items-center py-4 bg-body-tertiary">

    <div class="main-content w-100 m-auto">
        <div class="card">
            <div class="card-body text-center">
                <h1 class="fw-bold mb-3">آپدیت پنل</h1>
                <h6 class="mb-4">جهت آپدیت کردن پنل از طریق دکمه زیر عمل کنید</h6>
                <button class="btn btn-primary" id="upgradeButton">درخواست آپدیت</button>

                <!-- Display upgrade progress -->
                <div id="updateStatus" style="display: none;" class="mt-3">
                    <hr />
                    <div class="spinner-grow text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <div class="spinner-grow text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <div class="spinner-grow text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <div class="spinner-grow text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <div>لطفا تا پایان عملیات منتظر بمانید</div>
                </div>
                <div id="resultUpdate" style="display: none;" class="mt-3">

                </div>
            </div>
        </div>
        <div class="text-center text-muted small mt-2">در صورت مواجه شدن خطا بعد از آپدیت لطفا با پشتیبانی تماس بگیرید.</div>
        <div class="text-center text-muted small mt-1"><a target="_blank" href="https://t.me/rocket_ssh_pro">t.me/rocket_ssh_pro</a></div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script>
        var baseUrl = "<?= $baseUrl ?>";
        $(document).ready(function() {
            // Upgrade button click event
            $('#upgradeButton').on('click', function() {
                // Display a message indicating the upgrade has started
                $('#updateStatus').show();
                $("#resultUpdate").hide();
                // AJAX request to upgrade.php
                $.ajax({
                    url: 'update.php',
                    type: 'post',
                    data: {
                        update: "1"
                    },
                    dataType: 'json',
                    success: function(response) {
                        $('#updateStatus').hide();
                        $("#resultUpdate").show();

                        var status = response.status;
                        var resultHtml = "<hr/>";

                        if (status == "success") {
                            resultHtml += "<div class='text-success fw-bold'>عملیات آپدیت با موفقیت انجام شد</div>";
                        } else {
                            resultHtml += `<div class='text-danger'>${response.message}</div>`
                        }
                        $("#resultUpdate").html(resultHtml)

                    },
                    error: function() {
                        $('#updateStatus').hide();
                        $("#resultUpdate").hide();
                    }
                });
            });
        });
    </script>

</body>

</html>
